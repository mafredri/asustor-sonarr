define(["handlebars"],function(Handlebars){

Handlebars.registerPartial("SeriesTypeSelectionPartial", Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<select class=\"form-control col-md-2 x-series-type\" name=\"seriesType\">\n    <option value=\"standard\">Standard</option>\n    <option value=\"daily\">Daily</option>\n    <option value=\"anime\">Anime</option>\n</select>\n";
  }))
Handlebars.registerPartial("StartingSeasonSelectionPartial", Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n        ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("0")
  },inverse:self.program(4, program4, data),fn:self.program(2, program2, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.seasonNumber), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.seasonNumber), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n            <option value=\"";
  if (helper = helpers.seasonNumber) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.seasonNumber); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">Specials</option>\n        ";
  return buffer;
  }

function program4(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n            <option value=\"";
  if (helper = helpers.seasonNumber) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.seasonNumber); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">Season ";
  if (helper = helpers.seasonNumber) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.seasonNumber); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</option>\n        ";
  return buffer;
  }

  buffer += "<select class=\"form-control col-md-2 starting-season x-starting-season\">\n\n\n    ";
  stack1 = helpers.each.call(depth0, depth0, {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n    <option value=\"5000000\">None</option>\n</select>\n";
  return buffer;
  }))
Handlebars.registerPartial("FormHelpPartial", Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n        <i class=\"icon-nd-form-info\" title=\"";
  if (helper = helpers.helpText) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.helpText); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\"/>\n    ";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n        <a href=\"";
  if (helper = helpers.helpLink) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.helpLink); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" class=\"help-link\"><i class=\"icon-info-sign\"/></a>\n    ";
  return buffer;
  }

  buffer += "<span class=\"col-sm-1 help-inline\">\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.helpText), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.helpLink), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</span>\n";
  return buffer;
  }))
Handlebars.registerPartial("ProfileSelectionPartial", Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <option value=\"";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</option>\n    ";
  return buffer;
  }

  buffer += "<select class=\"col-md-2 form-control x-profile\">\n    ";
  stack1 = helpers.each.call(depth0, depth0, {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</select>";
  return buffer;
  }))
Handlebars.registerPartial("RootFolderSelectionPartial", Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n    ";
  stack1 = helpers.each.call(depth0, depth0, {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <option value=\"";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (helper = helpers.path) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.path); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</option>\n    ";
  return buffer;
  }

function program4(depth0,data) {
  
  
  return "\n    <option value=\"\">Select Path</option>\n    ";
  }

  buffer += "<select class=\"col-md-4 form-control x-root-folder\" validation-name=\"RootFolderPath\">\n    ";
  stack1 = helpers['if'].call(depth0, depth0, {hash:{},inverse:self.program(4, program4, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    <option value=\"addNew\">Add a different path</option>\n</select>\n\n";
  return buffer;
  }))
Handlebars.registerPartial("EpisodeProgressPartial", Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"progress episode-progress\">\n    <span class=\"progressbar-back-text\">";
  if (helper = helpers.episodeFileCount) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.episodeFileCount); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " / ";
  if (helper = helpers.episodeCount) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.episodeCount); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n    <div class=\"progress-bar ";
  if (helper = helpers.EpisodeProgressClass) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.EpisodeProgressClass); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " episode-progress\" style=\"width:";
  if (helper = helpers.percentOfEpisodes) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.percentOfEpisodes); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "%\"><span class=\"progressbar-front-text\">";
  if (helper = helpers.episodeFileCount) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.episodeFileCount); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " / ";
  if (helper = helpers.episodeCount) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.episodeCount); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span></div>\n</div>";
  return buffer;
  }))
Handlebars.registerPartial("AbsoluteEpisodeNamingPartial", Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<li class=\"dropdown-submenu\">\n    <a href=\"#\" tabindex=\"-1\" data-token=\"absolute\">Absolute</a>\n    <ul class=\"dropdown-menu\">\n        <li><a href=\"#\" data-token=\"absolute\">1</a></li>\n        <li><a href=\"#\" data-token=\"absolute:00\">01</a></li>\n        <li><a href=\"#\" data-token=\"absolute:000\">001</a></li>\n    </ul>\n</li>\n";
  }))
Handlebars.registerPartial("AirDateNamingPartial", Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<li class=\"dropdown-submenu\">\n    <a href=\"#\" tabindex=\"-1\" data-token=\"Air-Date\">Air-Date</a>\n    <ul class=\"dropdown-menu\">\n        <li><a href=\"#\" data-token=\"Air-Date\">Air-Date</a></li>\n        <li><a href=\"#\" data-token=\"Air Date\">Air Date</a></li>\n        <li><a href=\"#\" data-token=\"Air.Date\">Air.Date</a></li>\n        <li><a href=\"#\" data-token=\"Air_Date\">Air_Date</a></li>\n    </ul>\n</li>\n";
  }))
Handlebars.registerPartial("EpisodeNamingPartial", Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<li class=\"dropdown-submenu\">\n    <a href=\"#\" tabindex=\"-1\" data-token=\"episode\">Episode</a>\n    <ul class=\"dropdown-menu\">\n        <li><a href=\"#\" data-token=\"episode\">1</a></li>\n        <li><a href=\"#\" data-token=\"episode:00\">01</a></li>\n    </ul>\n</li>\n";
  }))
Handlebars.registerPartial("EpisodeTitleNamingPartial", Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<li class=\"dropdown-submenu\">\n    <a href=\"#\" tabindex=\"-1\" data-token=\"Episode Title\">Episode Title</a>\n    <ul class=\"dropdown-menu\">\n        <li><a href=\"#\" data-token=\"Episode Title\">Episode Title</a></li>\n        <li><a href=\"#\" data-token=\"Episode.Title\">Episode.Title</a></li>\n        <li><a href=\"#\" data-token=\"Episode_Title\">Episode_Title</a></li>\n        <li><a href=\"#\" data-token=\"Episode CleanTitle\">Episode CleanTitle</a></li>\n        <li><a href=\"#\" data-token=\"Episode.CleanTitle\">Episode.CleanTitle</a></li>\n        <li><a href=\"#\" data-token=\"Episode_CleanTitle\">Episode_CleanTitle</a></li>\n    </ul>\n</li>\n";
  }))
Handlebars.registerPartial("MediaInfoNamingPartial", Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<li class=\"dropdown-submenu\">\n    <a href=\"#\" tabindex=\"-1\" data-token=\"MediaInfo.Simple\">MediaInfo</a>\n    <ul class=\"dropdown-menu\">\n        <li><a href=\"#\" data-token=\"MediaInfo Simple\">MediaInfo Simple</a></li>\n        <li><a href=\"#\" data-token=\"MediaInfo.Simple\">MediaInfo.Simple</a></li>\n        <li><a href=\"#\" data-token=\"MediaInfo_Simple\">MediaInfo_Simple</a></li>\n        <li><a href=\"#\" data-token=\"MediaInfo Full\">MediaInfo Full</a></li>\n        <li><a href=\"#\" data-token=\"MediaInfo.Full\">MediaInfo.Full</a></li>\n        <li><a href=\"#\" data-token=\"MediaInfo_Full\">MediaInfo_Full</a></li>\n    </ul>\n</li>\n";
  }))
Handlebars.registerPartial("OriginalTitleNamingPartial", Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<li><a href=\"#\" data-token=\"Original Title\">Original Title</a></li>";
  }))
Handlebars.registerPartial("QualityNamingPartial", Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<li class=\"dropdown-submenu\">\n    <a href=\"#\" tabindex=\"-1\" data-token=\"Quality Full\">Quality</a>\n    <ul class=\"dropdown-menu\">\n        <li><a href=\"#\" data-token=\"Quality Full\">Quality Full</a></li>\n        <li><a href=\"#\" data-token=\"Quality.Full\">Quality.Full</a></li>\n        <li><a href=\"#\" data-token=\"Quality_Full\">Quality_Full</a></li>\n        <li><a href=\"#\" data-token=\"Quality Title\">Quality Title</a></li>\n        <li><a href=\"#\" data-token=\"Quality.Title\">Quality.Title</a></li>\n        <li><a href=\"#\" data-token=\"Quality_Title\">Quality_Title</a></li>\n    </ul>\n</li>\n";
  }))
Handlebars.registerPartial("ReleaseGroupNamingPartial", Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<li class=\"dropdown-submenu\">\n    <a href=\"#\" tabindex=\"-1\" data-token=\"Release Group\">Release Group</a>\n    <ul class=\"dropdown-menu\">\n        <li><a href=\"#\" data-token=\"Release Group\">Release Group</a></li>\n        <li><a href=\"#\" data-token=\"Release.Group\">Release.Group</a></li>\n        <li><a href=\"#\" data-token=\"Release_Group\">Release_Group</a></li>\n    </ul>\n</li>\n";
  }))
Handlebars.registerPartial("SeasonNamingPartial", Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<li class=\"dropdown-submenu\">\n    <a href=\"#\" tabindex=\"-1\" data-token=\"season\">Season</a>\n    <ul class=\"dropdown-menu\">\n        <li><a href=\"#\" data-token=\"season\">1</a></li>\n        <li><a href=\"#\" data-token=\"season:00\">01</a></li>\n    </ul>\n</li>\n";
  }))
Handlebars.registerPartial("SeparatorNamingPartial", Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<li class=\"dropdown-submenu\">\n    <a href=\"#\" tabindex=\"-1\" data-separator=\" - \">Separator</a>\n    <ul class=\"dropdown-menu\">\n        <li><a href=\"#\" data-separator=\" - \">Space-Dash-Space</a></li>\n        <li><a href=\"#\" data-separator=\"-\">Dash</a></li>\n        <li><a href=\"#\" data-separator=\" \">Space</a></li>\n        <li><a href=\"#\" data-separator=\".\">Period</a></li>\n        <li><a href=\"#\" data-separator=\"_\">Underscore</a></li>\n    </ul>\n</li>\n";
  }))
Handlebars.registerPartial("SeriesTitleNamingPartial", Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<li class=\"dropdown-submenu\">\n    <a href=\"#\" tabindex=\"-1\" data-token=\"Series Title\">Series Title</a>\n    <ul class=\"dropdown-menu\">\n        <li><a href=\"#\" data-token=\"Series Title\">Series Title</a></li>\n        <li><a href=\"#\" data-token=\"Series.Title\">Series.Title</a></li>\n        <li><a href=\"#\" data-token=\"Series_Title\">Series_Title</a></li>\n        <li><a href=\"#\" data-token=\"Series CleanTitle\">Series CleanTitle</a></li>\n        <li><a href=\"#\" data-token=\"Series.CleanTitle\">Series.CleanTitle</a></li>\n        <li><a href=\"#\" data-token=\"Series_CleanTitle\">Series_CleanTitle</a></li>\n    </ul>\n</li>\n";
  }))
this["T"] = this["T"] || {};
this["T"]["activity/activitylayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<ul class=\"nav nav-tabs\">\n    <li><a href=\"#queue\" class=\"x-queue-tab no-router\">Queue</a></li>\n    <li><a href=\"#history\" class=\"x-history-tab no-router\">History</a></li>\n    <li><a href=\"#blacklist\" class=\"x-blacklist-tab no-router\">Blacklist</a></li>\n</ul>\n\n<div class=\"tab-content\">\n    <div class=\"tab-pane\" id=\"queue\"></div>\n    <div class=\"tab-pane\" id=\"history\"></div>\n    <div class=\"tab-pane\" id=\"blacklist\"></div>\n</div>";
  };
this["T"]["addseries/addserieslayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div class=\"btn-group add-series-btn-group btn-group-lg btn-block\">\n            <button type=\"button\" class=\"btn btn-default col-md-10 col-xs-8 add-series-import-btn x-import\">\n                <i class=\"icon-hdd\"/>\n                Import existing series on disk\n            </button>\n            <button class=\"btn btn-default col-md-2 col-xs-4 x-add-new\"><i class=\"icon-play hidden-xs\"></i> Add new series</button>\n        </div>\n    </div>\n</div>\n<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div id=\"add-series-workspace\"></div>\n    </div>\n</div>\n\n";
  };
this["T"]["addseries/addseriesview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n<div class=\"unmapped-folder-path\">\n    <div class=\"col-md-12\">\n        "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.folder)),stack1 == null || stack1 === false ? stack1 : stack1.path)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\n    </div>\n</div>";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n        <input type=\"text\" class=\"form-control x-series-search\" value=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.folder)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\">\n        ";
  return buffer;
  }

function program5(depth0,data) {
  
  
  return "\n        <input type=\"text\" class=\"form-control x-series-search\" placeholder=\"Start typing the name of series you want to add ...\">\n        ";
  }

  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.folder)),stack1 == null || stack1 === false ? stack1 : stack1.path), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n<div class=\"x-search-bar\">\n    <div class=\"input-group input-group-lg add-series-search\">\n        <span class=\"input-group-addon\"><i class=\"icon-search\"/></span>\n\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.folder), {hash:{},inverse:self.program(5, program5, data),fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n</div>\n<div class=\"row\">\n    <div id=\"search-result\" class=\"result-list col-md-12\"/>\n</div>\n<div class=\"btn btn-block text-center new-series-loadmore x-load-more\" style=\"display: none;\">\n    <i class=\"icon-angle-down\"/>\n    more\n</div>\n";
  return buffer;
  };
this["T"]["addseries/emptyview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"text-center hint col-md-12\">\n    <span>You can also search by tvdbid using the tvdb: prefixes.</span>\n</div>\n";
  };
this["T"]["addseries/errorview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"text-center col-md-12\">\n    <h3>\n        There was an error searching for '";
  if (helper = helpers.term) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.term); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "'.\n    </h3>\n\n    If the series title contains non-alphanumeric characters try removing them, otherwise try your search again later.\n</div>\n";
  return buffer;
  };
this["T"]["addseries/notfoundview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"text-center col-md-12\">\n    <h3>\n        Sorry. We couldn't find any series matching '";
  if (helper = helpers.term) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.term); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "'\n    </h3>\n    <a href=\"https://github.com/NzbDrone/NzbDrone/wiki/FAQ#wiki-why-cant-i-add-a-new-show-to-nzbdrone-its-on-thetvdb\">Why can't I find my show?</a>\n\n</div>\n";
  return buffer;
  };
this["T"]["addseries/searchresultview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); partials = this.merge(partials, Handlebars.partials); data = data || {};
  var buffer = "", stack1, helper, options, self=this, functionType="function", escapeExpression=this.escapeExpression, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  
  return "search-item-new";
  }

function program3(depth0,data) {
  
  
  return "\n                                <span class=\"label label-danger\">Ended</span>\n                            ";
  }

function program5(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n                    ";
  stack1 = helpers.unless.call(depth0, (depth0 && depth0.path), {hash:{},inverse:self.noop,fn:self.program(6, program6, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n                    <div class=\"form-group col-md-2\">\n                        <label>Starting Season</label>\n                        ";
  stack1 = self.invokePartial(partials.StartingSeasonSelectionPartial, 'StartingSeasonSelectionPartial', (depth0 && depth0.seasons), helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                    </div>\n\n                    <div class=\"form-group col-md-2\">\n                        <label>Profile</label>\n                        ";
  stack1 = self.invokePartial(partials.ProfileSelectionPartial, 'ProfileSelectionPartial', (depth0 && depth0.profiles), helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                    </div>\n\n                    <div class=\"form-group col-md-2\">\n                        <label>Series Type</label>\n                        ";
  stack1 = self.invokePartial(partials.SeriesTypeSelectionPartial, 'SeriesTypeSelectionPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                    </div>\n\n                    <div class=\"form-group col-md-2\">\n                        <label>Season Folders</label>\n\n                        <div class=\"input-group\">\n                            <label class=\"checkbox toggle well\">\n                                <input type=\"checkbox\" class=\"x-season-folder\"/>\n                                <p>\n                                    <span>Yes</span>\n                                    <span>No</span>\n                                </p>\n                                <div class=\"btn btn-primary slide-button\"/>\n                            </label>\n                        </div>\n                    </div>\n                ";
  return buffer;
  }
function program6(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n                        <div class=\"form-group col-md-4\">\n                            <label>Path</label>\n                            ";
  stack1 = self.invokePartial(partials.RootFolderSelectionPartial, 'RootFolderSelectionPartial', (depth0 && depth0.rootFolders), helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                        </div>\n                    ";
  return buffer;
  }

function program8(depth0,data) {
  
  
  return "\n                    <div class=\"form-group col-md-2 col-md-offset-10\">\n                        <!--Uncomment if we need to add even more controls to add series-->\n                        <!--<label>&nbsp;</label>-->\n                        <button class=\"btn btn-success x-add\"> Add\n                            <i class=\"icon-plus\"></i>\n                        </button>\n                    </div>\n                ";
  }

function program10(depth0,data) {
  
  
  return "\n                    <div class=\"col-md-2 col-md-offset-10\">\n                        <button class=\"btn add-series disabled\">\n                            Already Exists\n                        </button>\n                    </div>\n                ";
  }

  buffer += "<div class=\"search-item ";
  stack1 = helpers.unless.call(depth0, (depth0 && depth0.isExisting), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\">\n    <div class=\"row\">\n        <div class=\"col-md-2\">\n            <a href=\"";
  if (helper = helpers.tvdbUrl) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.tvdbUrl); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" target=\"_blank\">\n                ";
  if (helper = helpers.poster) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.poster); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n            </a>\n        </div>\n        <div class=\"col-md-10\">\n            <div class=\"row\">\n                <div class=\"col-md-12\">\n                    <h2 class=\"series-title\">\n                        ";
  if (helper = helpers.titleWithYear) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.titleWithYear); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n\n                        <span class=\"labels\">\n                            <span class=\"label label-default\">";
  if (helper = helpers.network) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.network); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n                            ";
  stack1 = (helper = helpers.unless_eq || (depth0 && depth0.unless_eq),options={hash:{
    'compare': ("continuing")
  },inverse:self.noop,fn:self.program(3, program3, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.status), options) : helperMissing.call(depth0, "unless_eq", (depth0 && depth0.status), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                        </span>\n                    </h2>\n                </div>\n            </div>\n            <div class=\"row new-series-overview x-overview\">\n                <div class=\"col-md-12 overview-internal\">\n                    ";
  if (helper = helpers.overview) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.overview); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n                </div>\n            </div>\n            <div class=\"row\">\n                ";
  stack1 = helpers.unless.call(depth0, (depth0 && depth0.existing), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            </div>\n            <div class=\"row\">\n                ";
  stack1 = helpers.unless.call(depth0, (depth0 && depth0.existing), {hash:{},inverse:self.program(10, program10, data),fn:self.program(8, program8, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            </div>\n        </div>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["calendar/calendarfeedview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        <h3>Sonarr Calendar feed</h3>\n    </div>\n    <div class=\"modal-body edit-series-modal\">\n        <div class=\"form-horizontal\">\n            <div class=\"form-group\">\n                <label class=\"col-sm-2 control-label\">iCal feed</label>\n                <div class=\"col-sm-1 col-sm-push-9 help-inline\">\n                    <i class=\"icon-nd-form-info\" title=\"Copy this url into your clients subscription form or use the subscribe button if your browser support webcal\" />\n                </div>\n                <div class=\"col-sm-9 col-sm-pull-1\">\n                    <div class=\"input-group ical-url\">\n                        <input type=\"text\" class=\"form-control x-ical-url\" value=\"";
  if (helper = helpers.icalHttpUrl) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.icalHttpUrl); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" readonly=\"readonly\" />\n                        <div class=\"input-group-btn\">\n                            <button class=\"btn btn-icon-only x-ical-copy\" title=\"Copy to clipboard\"><i class=\"icon-copy\"></i></button>\n                            <button class=\"btn btn-icon-only no-router\" title=\"Subscribe\" href=\"";
  if (helper = helpers.icalWebCalUrl) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.icalWebCalUrl); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" target=\"_blank\" data-container=\".modal-body\"><i class=\"icon-calendar-empty\"></i></button>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </div>\n    <div class=\"modal-footer\">\n        <button class=\"btn\" data-dismiss=\"modal\">close</button>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["calendar/calendarlayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"row\">\n    <div class=\"col-md-3 hidden-xs\">\n        <div class=\"pull-left\">\n            <h4>Upcoming</h4>\n        </div>\n        <div class=\"pull-right\">\n            <h4>\n                <i class=\"icon-calendar-empty ical x-ical\"></i>\n            </h4>\n        </div>\n        <div id=\"x-upcoming\"/>\n    </div>\n    <div class=\"col-md-9 col-xs-12\">\n        <div id=\"x-calendar\" class=\"calendar\"/>\n        <div class=\"legend calendar\">\n            <ul class='legend-labels'>\n                <li><span class=\"premiere\" title=\"Premiere episode hasn't aired yet\"></span>Unaired Premiere</li>\n                <li><span class=\"primary\" title=\"Episode hasn't aired yet\"></span>Unaired</li>\n                <li><span class=\"warning\" title=\"Episode is currently airing\"></span>On Air</li>\n                <li><span class=\"purple\" title=\"Episode is currently downloading\"></span>Downloading</li>\n                <li><span class=\"danger\" title=\"Episode file has not been found\"></span>Missing</li>\n                <li><span class=\"success\" title=\"Episode was downloaded and sorted\"></span>Downloaded</li>\n            </ul>\n         </div>\n    </div>\n</div>\n";
  };
this["T"]["calendar/upcomingitemview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, helperMissing=helpers.helperMissing, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <a href=\"";
  if (helper = helpers.route) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.route); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n        <h4>";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h4>\n    </a>\n    ";
  return buffer;
  }

function program3(depth0,data) {
  
  var helper, options;
  return escapeExpression((helper = helpers.ShortDate || (depth0 && depth0.ShortDate),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.airDateUtc), options) : helperMissing.call(depth0, "ShortDate", (depth0 && depth0.airDateUtc), options)));
  }

  buffer += "<div class=\"event\">\n    <div class=\"date ";
  if (helper = helpers.StatusLevel) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.StatusLevel); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n        <h1>"
    + escapeExpression((helper = helpers.Day || (depth0 && depth0.Day),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.airDateUtc), options) : helperMissing.call(depth0, "Day", (depth0 && depth0.airDateUtc), options)))
    + "</h1>\n        <h4>"
    + escapeExpression((helper = helpers.Month || (depth0 && depth0.Month),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.airDateUtc), options) : helperMissing.call(depth0, "Month", (depth0 && depth0.airDateUtc), options)))
    + "</h4>\n    </div>\n    ";
  stack1 = helpers['with'].call(depth0, (depth0 && depth0.series), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    <p>"
    + escapeExpression((helper = helpers.StartTime || (depth0 && depth0.StartTime),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.airDateUtc), options) : helperMissing.call(depth0, "StartTime", (depth0 && depth0.airDateUtc), options)))
    + " ";
  stack1 = (helper = helpers.unless_today || (depth0 && depth0.unless_today),options={hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.airDateUtc), options) : helperMissing.call(depth0, "unless_today", (depth0 && depth0.airDateUtc), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</p>\n    <p>\n        <span class=\"episode-title x-episode-title\">\n            ";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n        </span>\n        <span class=\"pull-right\">";
  if (helper = helpers.seasonNumber) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.seasonNumber); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "x"
    + escapeExpression((helper = helpers.Pad2 || (depth0 && depth0.Pad2),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.episodeNumber), options) : helperMissing.call(depth0, "Pad2", (depth0 && depth0.episodeNumber), options)))
    + "</span>\n    </p>\n</div>\n";
  return buffer;
  };
this["T"]["cells/approvalstatuscell"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "";
  buffer += "\n    <li>"
    + escapeExpression((typeof depth0 === functionType ? depth0.apply(depth0) : depth0))
    + "</li>\n    ";
  return buffer;
  }

  buffer += "<ul>\n    ";
  stack1 = helpers.each.call(depth0, depth0, {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</ul>\n";
  return buffer;
  };
this["T"]["cells/episodeprogresscell"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); partials = this.merge(partials, Handlebars.partials); data = data || {};
  var stack1, self=this;


  stack1 = self.invokePartial(partials.EpisodeProgressPartial, 'EpisodeProgressPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { return stack1; }
  else { return ''; }
  };
this["T"]["cells/qualitycell"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n    <span class=\"badge badge-info\" title=\"PROPER\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.quality)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</span>\n";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n    <span class=\"badge\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.quality)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</span>\n";
  return buffer;
  }

  stack1 = (helper = helpers.if_gt || (depth0 && depth0.if_gt),options={hash:{
    'compare': ("1")
  },inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.proper), options) : helperMissing.call(depth0, "if_gt", (depth0 && depth0.proper), options));
  if(stack1 || stack1 === 0) { return stack1; }
  else { return ''; }
  };
this["T"]["cells/seriestitle"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<a href=\"";
  if (helper = helpers.route) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.route); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</a>\n";
  return buffer;
  };
this["T"]["episode/episodedetailslayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n                ";
  stack1 = helpers['with'].call(depth0, (depth0 && depth0.series), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                    <a href=\"";
  if (helper = helpers.route) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.route); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" class=\"btn btn-default pull-left\" data-dismiss=\"modal\">Go to Series</a>\n                ";
  return buffer;
  }

  buffer += "<div class=\"modal-content\">\n    <div class=\"episode-detail-modal\">\n        <div class=\"modal-header\">\n            <span class=\"hidden-series-title x-series-title\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.series)),stack1 == null || stack1 === false ? stack1 : stack1.title)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</span>\n            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n\n            <h3>\n                <i class=\"icon-bookmark x-episode-monitored episode-monitored\" title=\"Toggle monitored status\" />\n                "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.series)),stack1 == null || stack1 === false ? stack1 : stack1.title)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + " - ";
  if (helper = helpers.EpisodeNumber) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.EpisodeNumber); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " - ";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n            </h3>\n\n        </div>\n        <div class=\"modal-body\">\n            <ul class=\"nav nav-tabs\" id=\"myTab\">\n                <li><a href=\"#episode-summary\" class=\"x-episode-summary\">Summary</a></li>\n                <li><a href=\"#episode-activity\" class=\"x-episode-activity\">Activity</a></li>\n                <li><a href=\"#episode-search\" class=\"x-episode-search\">Search</a></li>\n            </ul>\n            <div class=\"tab-content\">\n                <div class=\"tab-pane\" id=\"episode-summary\"/>\n                <div class=\"tab-pane\" id=\"episode-activity\"/>\n                <div class=\"tab-pane\" id=\"episode-search\"/>\n            </div>\n        </div>\n        <div class=\"modal-footer\">\n            ";
  stack1 = helpers.unless.call(depth0, (depth0 && depth0.hideSeriesLink), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n            <button class=\"btn btn-default\" data-dismiss=\"modal\">close</button>\n        </div>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["form/checkbox"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  
  return "advanced-setting";
  }

function program3(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                <span class=\"help-inline-checkbox\">\n                    <i class=\"icon-nd-form-info\" title=\"";
  if (helper = helpers.helpText) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.helpText); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\"/>\n                </span>\n            ";
  return buffer;
  }

  buffer += "<div class=\"form-group ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.advanced), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\">\n    <label class=\"col-sm-3 control-label\">";
  if (helper = helpers.label) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.label); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</label>\n\n    <div class=\"col-sm-5\">\n        <div class=\"input-group\">\n            <label class=\"checkbox toggle well\">\n                <input type=\"checkbox\" name=\"fields.";
  if (helper = helpers.order) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.order); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + ".value\"/>\n                <p>\n                    <span>Yes</span>\n                    <span>No</span>\n                </p>\n\n                <div class=\"btn btn-primary slide-button\"/>\n            </label>\n\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.helpText), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </div>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["form/password"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); partials = this.merge(partials, Handlebars.partials); data = data || {};
  var buffer = "", stack1, helper, self=this, functionType="function", escapeExpression=this.escapeExpression;

function program1(depth0,data) {
  
  
  return "advanced-setting";
  }

  buffer += "<div class=\"form-group ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.advanced), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\">\n    <label class=\"col-sm-3 control-label\">";
  if (helper = helpers.label) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.label); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</label>\n\n    <div class=\"col-sm-5\">\n        <input type=\"password\" name=\"fields.";
  if (helper = helpers.order) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.order); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + ".value\" validation-name=\"";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" class=\"form-control\"/>\n    </div>\n    ";
  stack1 = self.invokePartial(partials.FormHelpPartial, 'FormHelpPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</div>\n";
  return buffer;
  };
this["T"]["form/path"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); partials = this.merge(partials, Handlebars.partials); data = data || {};
  var buffer = "", stack1, helper, self=this, functionType="function", escapeExpression=this.escapeExpression;

function program1(depth0,data) {
  
  
  return "advanced-setting";
  }

  buffer += "<div class=\"form-group ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.advanced), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\">\n    <label class=\"col-sm-3 control-label\">";
  if (helper = helpers.label) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.label); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</label>\n\n    <div class=\"col-sm-5\">\n        <input type=\"text\" name=\"fields.";
  if (helper = helpers.order) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.order); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + ".value\" validation-name=\"";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" class=\"form-control x-path\"/>\n    </div>\n    ";
  stack1 = self.invokePartial(partials.FormHelpPartial, 'FormHelpPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</div>\n";
  return buffer;
  };
this["T"]["form/select"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); partials = this.merge(partials, Handlebars.partials); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  
  return "advanced-setting";
  }

function program3(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                <option value=\"";
  if (helper = helpers.value) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.value); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</option>\n            ";
  return buffer;
  }

  buffer += "<div class=\"form-group ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.advanced), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\">\n    <label class=\"col-sm-3 control-label\">";
  if (helper = helpers.label) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.label); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</label>\n\n    <div class=\"col-sm-5\">\n        <select name=\"fields.";
  if (helper = helpers.order) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.order); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + ".value\" class=\"form-control\">\n            ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.selectOptions), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </select>\n    </div>\n    ";
  stack1 = self.invokePartial(partials.FormHelpPartial, 'FormHelpPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</div>\n";
  return buffer;
  };
this["T"]["form/textbox"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); partials = this.merge(partials, Handlebars.partials); data = data || {};
  var buffer = "", stack1, helper, self=this, functionType="function", escapeExpression=this.escapeExpression;

function program1(depth0,data) {
  
  
  return "advanced-setting";
  }

  buffer += "<div class=\"form-group ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.advanced), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\">\n    <label class=\"col-sm-3 control-label\">";
  if (helper = helpers.label) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.label); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</label>\n\n    <div class=\"col-sm-5\">\n        <input type=\"text\" name=\"fields.";
  if (helper = helpers.order) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.order); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + ".value\" validation-name=\"";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" spellcheck=\"false\" class=\"form-control\"/>\n    </div>\n    ";
  stack1 = self.invokePartial(partials.FormHelpPartial, 'FormHelpPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</div>\n";
  return buffer;
  };
this["T"]["hotkeys/hotkeysview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        <h3>Keyboard Shortcuts</h3>\n    </div>\n    <div class=\"modal-body hotkeys-modal\">\n        <div class=\"row hotkey-group\">\n            <div class=\"col-md-12\">\n                <div class=\"row\">\n                    <div class=\"col-md-5 col-md-offset-1\">\n                        <h3>Focus Search Box</h3>\n                    </div>\n                    <div class=\"col-md-3\">\n                        <kbd class=\"hotkey\">t</kbd>\n                    </div>\n                </div>\n                <div class=\"row\">\n                    <div class=\"col-md-11 col-md-offset-1\">\n                        Pressing 't' puts the cursor in the search box below the navigation links\n                    </div>\n                </div>\n            </div>\n        </div>\n        <div class=\"row hotkey-group\">\n            <div class=\"col-md-12\">\n                <div class=\"row\">\n                    <div class=\"col-md-5 col-md-offset-1\">\n                        <h3>Save Settings</h3>\n                    </div>\n                    <div class=\"col-md-3\">\n                        <kbd class=\"hotkey\">ctrl + s</kbd>\n                    </div>\n                </div>\n                <div class=\"row\">\n                    <div class=\"col-md-11 col-md-offset-1\">\n                        Pressing ctrl + 's' saves your settings (only in settings)\n                    </div>\n                </div>\n            </div>\n        </div>\n    </div>\n    <div class=\"modal-footer\">\n        <button class=\"btn\" data-dismiss=\"modal\">close</button>\n    </div>\n</div>\n";
  };
this["T"]["navbar/navbarlayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<!-- Static navbar -->\n<div class=\"navbar navbar-nzbdrone\" role=\"navigation\">\n    <div class=\"container-fluid\">\n        <div class=\"navbar-header\">\n            <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">\n                <span class=\"sr-only\">Toggle navigation</span>\n                <span class=\"icon-bar\"></span>\n                <span class=\"icon-bar\"></span>\n                <span class=\"icon-bar\"></span>\n            </button>\n            <a class=\"navbar-brand\" href=\"";
  if (helper = helpers.UrlBase) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.UrlBase); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/\">\n                <!--<img src=\"";
  if (helper = helpers.UrlBase) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.UrlBase); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/Content/Images/logo.png?v=2\" alt=\"Sonarr\">-->\n                <img src=\"";
  if (helper = helpers.UrlBase) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.UrlBase); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/Content/Images/logos/128.png\" class=\"visible-lg\"/>\n                <img src=\"";
  if (helper = helpers.UrlBase) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.UrlBase); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/Content/Images/logos/64.png\" class=\"visible-md visible-sm\"/>\n                <span class=\"visible-xs\">\n                    <img src=\"";
  if (helper = helpers.UrlBase) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.UrlBase); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/Content/Images/logos/32.png\"/>\n                    <span class=\"logo-text\">sonarr</span>\n                </span>\n\n            </a>\n        </div>\n        <div class=\"navbar-collapse collapse x-navbar-collapse\">\n            <ul class=\"nav navbar-nav\">\n                <li><a href=\"";
  if (helper = helpers.UrlBase) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.UrlBase); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/\" class=\"x-series-nav\"><i class=\"icon-play\"></i> Series</a></li>\n                <li><a href=\"";
  if (helper = helpers.UrlBase) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.UrlBase); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/calendar\" class=\"x-calendar-nav\"><i class=\"icon-calendar\"></i> Calendar</a></li>\n                <li><a href=\"";
  if (helper = helpers.UrlBase) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.UrlBase); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/activity\" class=\"x-activity-nav\"><i class=\"icon-time\"></i> Activity<span id=\"x-queue-count\" class=\"navbar-info\"></span></a></li>\n                <li><a href=\"";
  if (helper = helpers.UrlBase) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.UrlBase); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/wanted\" class=\"x-wanted-nav\"><i class=\"icon-warning-sign\"></i> Wanted</a></li>\n                <li><a href=\"";
  if (helper = helpers.UrlBase) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.UrlBase); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/settings\" class=\"x-settings-nav\"><i class=\"icon-cogs\"></i> Settings</a></li>\n                <li><a href=\"";
  if (helper = helpers.UrlBase) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.UrlBase); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/system\" class=\"x-system-nav\"><i class=\"icon-laptop\"></i> System<span id=\"x-health\" class=\"navbar-info\"></span></a></li>\n                <li><a href=\"https://sonarr.tv/donate\" target=\"_blank\"><i class=\"icon-nd-donate\"></i> Donate</a></li>\n            </ul>\n            <ul class=\"nav navbar-nav navbar-right\">\n                <li class=\"active screen-size\"></li>\n            </ul>\n        </div><!--/.nav-collapse -->\n    </div><!--/.container-fluid -->\n\n    <div class=\"col-md-12 search\">\n        <div class=\"col-md-6 col-md-offset-3\">\n            <div class=\"input-group\">\n                <span class=\"input-group-addon\"><i class=\"icon-search\"></i></span>\n                <input type=\"text\" class=\"col-md-6 form-control x-series-search\" placeholder=\"Search the series in your library\">\n            </div>\n        </div>\n    </div>\n</div>";
  return buffer;
  };
this["T"]["release/releaselayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div id=\"x-toolbar\"/>\n<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div id=\"x-grid\"/>\n    </div>\n</div>\n\n";
  };
this["T"]["rename/renamepreviewemptycollectionview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"alert alert-success\">\n    Success! My work is done, no files to rename.\n</div>";
  };
this["T"]["rename/renamepreviewformatview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    ";
  if (helper = helpers.format) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.format); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n";
  return buffer;
  }

  buffer += "<span class=\"file-name-format\">\n";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.rename), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</span>\n";
  return buffer;
  };
this["T"]["rename/renamepreviewitemview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"rename-preview-item\">\n    <div class=\"row\">\n        <div class=\"rename-checkbox col-md-1\">\n            <label class=\"checkbox-button\" title=\"Rename File\">\n                <input type=\"checkbox\" name=\"rename\"/>\n                <div class=\"btn\">\n                    <i></i>\n                </div>\n            </label>\n        </div>\n        <div class=\"col-md-11\">\n            <div class=\"row\">\n                <div class=\"col-md-12 file-path\"><i class=\"icon-nd-existing\" title=\"Existing path\" /> ";
  if (helper = helpers.existingPath) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.existingPath); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</div>\n            </div>\n            <div class=\"row\">\n                <div class=\"col-md-12 file-path\"><i class=\"icon-nd-suggested\" title=\"Suggested path\" /> ";
  if (helper = helpers.newPath) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.newPath); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</div>\n            </div>\n        </div>\n    </div>\n</div>";
  return buffer;
  };
this["T"]["rename/renamepreviewlayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"modal-content\">\n    <div class=\"rename-preview-modal\">\n        <div class=\"modal-header\">\n            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n            <h3>\n                <i class=\"icon-nd-rename\"></i> Organize & Rename\n            </h3>\n\n        </div>\n        <div class=\"modal-body\">\n            <div class=\"alert alert-info path-info x-path-info\">All paths are relative to: <strong>";
  if (helper = helpers.path) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.path); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</strong></div>\n\n            <div id=\"rename-previews\"></div>\n\n        </div>\n        <div class=\"modal-footer\">\n\n            <span class=\"rename-all-button x-rename-all-button pull-left\">\n                <label class=\"checkbox-button\" title=\"Toggle all\">\n                    <input type=\"checkbox\" checked=\"checked\" class=\"x-rename-all\"/>\n                    <div class=\"btn btn-icon-only\">\n                        <i class=\"icon-check\"></i>\n                    </div>\n                </label>\n            </span>\n            <span class=\"x-format-region pull-left\"></span>\n\n            <button class=\"btn\" data-dismiss=\"modal\">close</button>\n            <button class=\"btn btn-primary x-organize\">Organize</button>\n        </div>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["seasonpass/seasonpasslayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div id=\"x-toolbar\"></div>\n\n<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div class=\"alert alert-info\">Season Pass allows you to quickly change the monitored status of seasons for all your series in one place</div>\n    </div>\n</div>\n\n<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div id=\"x-series\"></div>\n    </div>\n</div>";
  };
this["T"]["seasonpass/serieslayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                        ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("0")
  },inverse:self.program(4, program4, data),fn:self.program(2, program2, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.seasonNumber), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.seasonNumber), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                    ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                            <option value=\"";
  if (helper = helpers.seasonNumber) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.seasonNumber); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">Specials</option>\n                        ";
  return buffer;
  }

function program4(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                            <option value=\"";
  if (helper = helpers.seasonNumber) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.seasonNumber); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">Season ";
  if (helper = helpers.seasonNumber) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.seasonNumber); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</option>\n                        ";
  return buffer;
  }

function program6(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                            <tr>\n                                <td class=\"toggle-cell x-monitored\" data-season-number=\"";
  if (helper = helpers.seasonNumber) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.seasonNumber); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n                                    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.monitored), {hash:{},inverse:self.program(9, program9, data),fn:self.program(7, program7, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                                </td>\n                                <td>\n                                    ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("0")
  },inverse:self.program(13, program13, data),fn:self.program(11, program11, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.seasonNumber), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.seasonNumber), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                                </td>\n                            </tr>\n                        ";
  return buffer;
  }
function program7(depth0,data) {
  
  
  return "\n                                        <i class=\"icon-nd-monitored\"></i>\n                                    ";
  }

function program9(depth0,data) {
  
  
  return "\n                                        <i class=\"icon-nd-unmonitored\"></i>\n                                    ";
  }

function program11(depth0,data) {
  
  
  return "\n                                        Specials\n                                    ";
  }

function program13(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                                        Season ";
  if (helper = helpers.seasonNumber) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.seasonNumber); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n                                    ";
  return buffer;
  }

  buffer += "<div class=\"seasonpass-series\">\n    <div class=\"row\">\n        <div class=\"col-md-12\">\n            <i class=\"icon-chevron-right x-expander expander pull-left\"/>\n            <i class=\"x-series-monitored series-monitor-toggle pull-left\" title=\"Toggle monitored state for entire series\"/>\n            <div class=\"title col-md-5\">\n                <a href=\"";
  if (helper = helpers.route) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.route); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n                    ";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n                </a>\n            </div>\n\n            <div class=\"col-md-2\">\n                <select class=\"form-control x-season-select season-select\">\n                    <option value=\"-1\">Select season...</option>\n                    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.seasons), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                </select>\n            </div>\n\n            <div class=\"col-md-1\">\n                <span class=\"help-inline\">\n                    <i class=\"icon-nd-form-info\" title=\"Selecting a season will unmonitor all previous seasons\"/>\n                </span>\n            </div>\n\n            <span class=\"season-pass-button\">\n                <button class=\"btn x-latest last\">Latest Season Only</button>\n            </span>\n\n            <span class=\"season-pass-button\">\n                <button class=\"btn x-all\">All Seasons</button>\n            </span>\n        </div>\n    </div>\n\n    <div class=\"row\">\n        <div class=\"col-md-11\">\n            <div class=\"x-season-grid season-grid\">\n                <table class=\"table table-striped\">\n                    <thead>\n                        <tr>\n                            <th></th>\n                            <th class=\"sortable\">Season</th>\n                        </tr>\n                    </thead>\n                    <tbody>\n                        ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.seasons), {hash:{},inverse:self.noop,fn:self.program(6, program6, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                    </tbody>\n                </table>\n            </div>\n        </div>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["settings/settingslayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<ul class=\"nav nav-tabs nav-justified settings-tabs\">\n    <li><a href=\"#media-management\" class=\"x-media-management-tab no-router\">Media Management</a></li>\n    <li><a href=\"#profiles\" class=\"x-profiles-tab no-router\">Profiles</a></li>\n    <li><a href=\"#quality\" class=\"x-quality-tab no-router\">Quality</a></li>\n    <li><a href=\"#indexers\" class=\"x-indexers-tab no-router\">Indexers</a></li>\n    <li><a href=\"#download-client\" class=\"x-download-client-tab no-router\">Download Client</a></li>\n    <li><a href=\"#notifications\" class=\"x-notifications-tab no-router\">Connect</a></li>\n    <li><a href=\"#metadata\" class=\"x-metadata-tab no-router\">Metadata</a></li>\n    <li><a href=\"#general\" class=\"x-general-tab no-router\">General</a></li>\n    <li><a href=\"#ui\" class=\"x-ui-tab no-router\">UI</a></li>\n</ul>\n\n<div class=\"row settings-controls\">\n    <div class=\"col-sm-4 col-sm-offset-7 col-md-3 col-md-offset-8\">\n        <div class=\"advanced-settings-toggle\">\n            <span class=\"help-inline-checkbox hidden-xs\">\n                Advanced Settings\n            </span>\n            <label class=\"checkbox toggle well\">\n                <input type=\"checkbox\" class=\"x-advanced-settings\"/>\n                <p>\n                    <span>Shown</span>\n                    <span>Hidden</span>\n                </p>\n                <div class=\"btn btn-warning slide-button\"/>\n            </label>\n            <span class=\"help-inline-checkbox hidden-sm hidden-md hidden-lg\">\n                Advanced Settings\n            </span>\n        </div>\n    </div>\n    <div class=\"col-sm-1 col-md-1\">\n        <button class=\"btn btn-primary x-save-settings\">Save</button>\n    </div>\n</div>\n\n<div class=\"tab-content\">\n    <div class=\"tab-pane\" id=\"media-management\"></div>\n    <div class=\"tab-pane\" id=\"profiles\"></div>\n    <div class=\"tab-pane\" id=\"quality\"></div>\n    <div class=\"tab-pane\" id=\"indexers\"></div>\n    <div class=\"tab-pane\" id=\"download-client\"></div>\n    <div class=\"tab-pane\" id=\"notifications\"></div>\n    <div class=\"tab-pane\" id=\"metadata\"></div>\n    <div class=\"tab-pane\" id=\"general\"></div>\n    <div class=\"tab-pane\" id=\"ui\"></div>\n</div>\n\n<div id=\"loading-region\"></div>";
  };
this["T"]["settings/thingyheadergroupview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<legend>";
  if (helper = helpers.header) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.header); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</legend>\n<ul class=\"item-list\" />";
  return buffer;
  };
this["T"]["shared/loadingview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"row\">\n    <div id=\"followingBalls\">\n        <div id=\"ball-1\" class=\"ball\"></div>\n        <div id=\"ball-2\" class=\"ball\"></div>\n        <div id=\"ball-3\" class=\"ball\"></div>\n        <div id=\"ball-4\" class=\"ball\"></div>\n    </div>\n</div>\n";
  };
this["T"]["shared/notfoundview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div>\n    <img src=\"";
  if (helper = helpers.UrlBase) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.UrlBase); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/Content/Images/404.png\" style=\"height:400px; margin-top: 50px\"/>\n\n</div>\n";
  return buffer;
  };
this["T"]["system/systemlayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<ul class=\"nav nav-tabs\">\n    <li><a href=\"#info\" class=\"x-info-tab no-router\">Info</a></li>\n    <li><a href=\"#logs\" class=\"x-logs-tab no-router\">Logs</a></li>\n    <li><a href=\"#updates\" class=\"x-updates-tab no-router\">Updates</a></li>\n    <li><a href=\"#backup\" class=\"x-backup-tab no-router\">Backup</a></li>\n    <li><a href=\"#tasks\" class=\"x-tasks-tab no-router\">Tasks</a></li>\n    <li class=\"lifecycle-controls pull-right\">\n        <div class=\"btn-group\">\n            <button class=\"btn btn-default btn-icon-only x-shutdown\" title=\"Shutdown\" data-container=\"body\">\n                <i class=\"icon-nd-shutdown\"></i>\n            </button>\n            <button class=\"btn btn-default btn-icon-only x-restart\" title=\"Restart\" data-container=\"body\">\n                <i class=\"icon-nd-restart\"></i>\n            </button>\n        </div>\n    </li>\n</ul>\n\n<div class=\"tab-content\">\n    <div class=\"tab-pane\" id=\"info\"></div>\n    <div class=\"tab-pane\" id=\"logs\"></div>\n    <div class=\"tab-pane\" id=\"updates\"></div>\n    <div class=\"tab-pane\" id=\"backup\"></div>\n    <div class=\"tab-pane\" id=\"tasks\"></div>\n</div>";
  };
this["T"]["wanted/controlscolumn"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<i class=\"icon-search x-search\" title=\"Search\"/>\n";
  };
this["T"]["wanted/wantedlayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<ul class=\"nav nav-tabs\">\n    <li><a href=\"#missing\" class=\"x-missing-tab no-router\">Missing</a></li>\n    <li><a href=\"#cutoff\" class=\"x-cutoff-tab no-router\">Cutoff Unmet</a></li>\n</ul>\n\n<div class=\"tab-pane\" id=\"content\"></div>\n<!--<div class=\"tab-content\">\n    <div class=\"tab-pane\" id=\"missing\"></div>\n    <div class=\"tab-pane\" id=\"cutoff\"></div>\n</div>-->";
  };
this["T"]["activity/blacklist/blacklistlayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div id=\"x-toolbar\"/>\n<div class=\"row\">\n    <div class=\"col-md-12 table-responsive\">\n        <div id=\"x-blacklist\"/>\n    </div>\n</div>\n<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div id=\"x-pager\"/>\n    </div>\n</div>\n";
  };
this["T"]["activity/history/historylayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div id=\"x-history-toolbar\"/>\n<div class=\"row\">\n    <div class=\"col-md-12 table-responsive\">\n        <div id=\"x-history\"/>\n    </div>\n</div>\n<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div id=\"x-history-pager\"/>\n    </div>\n</div>\n";
  };
this["T"]["activity/queue/queuelayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"row\">\n    <div class=\"col-md-12 table-responsive\">\n        <div id=\"x-queue\"/>\n    </div>\n</div>\n\n<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div id=\"x-queue-pager\"/>\n    </div>\n</div>";
  };
this["T"]["activity/queue/queuestatuscell"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    ";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n    <ul>\n        ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.messages), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </ul>\n";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "";
  buffer += "\n            <li>"
    + escapeExpression((typeof depth0 === functionType ? depth0.apply(depth0) : depth0))
    + "</li>\n        ";
  return buffer;
  }

  stack1 = helpers.each.call(depth0, (depth0 && depth0.statusMessages), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { return stack1; }
  else { return ''; }
  };
this["T"]["addseries/existing/addexistingseriescollectionview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"x-existing-folders\">\n    <div class=\"loading-folders x-loading-folders\">\n        Loading search results from trakt for your series, this may take a few minutes.\n    </div>\n</div>";
  };
this["T"]["addseries/rootfolders/rootfoldercollectionview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<table class=\"table table-hover\">\n    <thead>\n        <tr>\n            <th class=\"col-md-10 \">\n                Path\n            </th>\n            <th class=\"col-md-3\">\n                Free Space\n            </th>\n        </tr>\n    </thead>\n    <tbody class=\"x-root-folders\"></tbody>\n</table>";
  };
this["T"]["addseries/rootfolders/rootfolderitemview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, helperMissing=helpers.helperMissing;


  buffer += "<td class=\"col-md-10 x-folder folder-path\">\n   ";
  if (helper = helpers.path) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.path); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n</td>\n<td class=\"col-md-3 x-folder folder-free-space\">\n    <span>"
    + escapeExpression((helper = helpers.Bytes || (depth0 && depth0.Bytes),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.freeSpace), options) : helperMissing.call(depth0, "Bytes", (depth0 && depth0.freeSpace), options)))
    + "</span>\n</td>\n<td class=\"col-md-1\">\n    <i class=\"icon-nd-delete x-delete\"></i>\n</td>\n";
  return buffer;
  };
this["T"]["addseries/rootfolders/rootfolderlayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, self=this;

function program1(depth0,data) {
  
  
  return "\n                    <h4>Recent Folders</h4>\n                ";
  }

  buffer += "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        <h3>Select Folder</h3>\n    </div>\n    <div class=\"modal-body root-folders-modal\">\n        <div class=\"validation-errors\"></div>\n        <div class=\"alert alert-info\">Enter the path that contains some or all of your TV series, you will be able to choose which series you want to import<button type=\"button\" class=\"close\" data-dismiss=\"alert\">×</button></div>\n\n        <div class=\"row\">\n            <div class=\"form-group\">\n\n                <div class=\"col-md-12\">\n\n                    <div class=\"input-group\">\n                        <span class=\"input-group-addon\">&nbsp;<i class=\"icon-folder-open\"></i></span>\n                        <input class=\"form-control x-path\" type=\"text\" validation-name=\"path\" placeholder=\"Enter path to folder that contains your shows\">\n                        <span class=\"input-group-btn\"><button class=\"btn btn-success x-add\"><i class=\"icon-ok\"/></button></span>\n                    </div>\n                </div>\n            </div>\n        </div>\n\n        <div class=\"row root-folders\">\n            <div class=\"col-md-12\">\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.items), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                <div id=\"current-dirs\" class=\"root-folders-list\"></div>\n            </div>\n        </div>\n    </div>\n    <div class=\"modal-footer\">\n        <button class=\"btn\" data-dismiss=\"modal\">close</button>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["cells/edit/qualitycelleditor"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n    ";
  stack1 = helpers['with'].call(depth0, (depth0 && depth0.quality), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.selected), {hash:{},inverse:self.program(5, program5, data),fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    ";
  return buffer;
  }
function program3(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n            <option value=\"";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" selected=\"selected\">";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</option>\n        ";
  return buffer;
  }

function program5(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n            <option value=\"";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</option>\n        ";
  return buffer;
  }

  stack1 = helpers.each.call(depth0, (depth0 && depth0.items), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { return stack1; }
  else { return ''; }
  };
this["T"]["episode/activity/episodeactivitylayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"activity-table table-responsive\"></div>";
  };
this["T"]["episode/activity/noactivityview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<p class=\"text-warning\">\n    No activity for this episode.\n</p>";
  };
this["T"]["episode/search/buttonsview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"search-buttons\">\n    <button class=\"btn btn-lg btn-block x-search-auto\"><i class=\"icon-rocket\"/> Automatic Search</button>\n    <button class=\"btn btn-lg btn-block btn-primary x-search-manual\"><i class=\"icon-user\"/> Manual Search</button>\n</div>";
  };
this["T"]["episode/search/episodesearchlayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div id=\"episode-search-region\"></div>";
  };
this["T"]["episode/search/manuallayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div id=\"episode-release-grid\" class=\"table-responsive\"></div>\n<button class=\"btn x-search-back\">Back</button>";
  };
this["T"]["episode/search/noresultsview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div>No results found</div>";
  };
this["T"]["episode/summary/episodesummarylayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, functionType="function", self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n        "
    + escapeExpression((helper = helpers.profile || (depth0 && depth0.profile),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.profileId), options) : helperMissing.call(depth0, "profile", (depth0 && depth0.profileId), options)))
    + "\n        <span class=\"label label-info\">";
  if (helper = helpers.network) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.network); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n    ";
  return buffer;
  }

  buffer += "<div class=\"episode-info\">\n    ";
  stack1 = helpers['with'].call(depth0, (depth0 && depth0.series), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    <span class=\"label label-info\">"
    + escapeExpression((helper = helpers.StartTime || (depth0 && depth0.StartTime),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.airDateUtc), options) : helperMissing.call(depth0, "StartTime", (depth0 && depth0.airDateUtc), options)))
    + "</span>\n    <span class=\"label label-info\">"
    + escapeExpression((helper = helpers.RelativeDate || (depth0 && depth0.RelativeDate),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.airDateUtc), options) : helperMissing.call(depth0, "RelativeDate", (depth0 && depth0.airDateUtc), options)))
    + "</span>\n</div>\n\n<div class=\"episode-overview\">\n    ";
  if (helper = helpers.overview) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.overview); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n</div>\n\n<div class=\"episode-file-info\"></div>\n";
  return buffer;
  };
this["T"]["episode/summary/nofileview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<p class=\"text-warning\">\n    No file available for this episode.\n</p>";
  };
this["T"]["series/delete/deleteseries"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        <h3>Delete ";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h3>\n    </div>\n    <div class=\"modal-body delete-series-modal\">\n\n        <div class=\"row\">\n            <div class=\"col-sm-3 hidden-xs\">\n                ";
  if (helper = helpers.poster) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.poster); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n            </div>\n            <div class=\"col-sm-9\">\n                <div class=\"form-horizontal\">\n                    <h3 class=\"path\">";
  if (helper = helpers.path) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.path); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h3>\n\n                    <div class=\"form-group\">\n                        <label class=\"col-sm-4 control-label\">Delete all files</label>\n\n                        <div class=\"col-sm-8\">\n                            <div class=\"input-group\">\n                                <label class=\"checkbox toggle well\">\n                                    <input type=\"checkbox\" class=\"x-delete-files\"/>\n                                    <p>\n                                        <span>Yes</span>\n                                        <span>No</span>\n                                    </p>\n\n                                    <div class=\"btn slide-button btn-danger\"/>\n                                </label>\n\n                                    <span class=\"help-inline-checkbox\">\n                                        <i class=\"icon-nd-form-info\" title=\"Do you want to delete all files from disk?\"/>\n                                        <i class=\"icon-nd-form-warning\" title=\"This option is irreversible, use with extreme caution\"/>\n                                    </span>\n                                </div>\n                        </div>\n                    </div>\n                    <div class=\"col-md-offset-1 col-md-5 delete-files-info x-delete-files-info\">\n                        ";
  if (helper = helpers.episodeFileCount) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.episodeFileCount); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " episode files will be deleted\n                    </div>\n                </div>\n            </div>\n        </div>\n    </div>\n    <div class=\"modal-footer\">\n        <span class=\"indicator x-indicator\"><i class=\"icon-spinner icon-spin\"></i></span>\n        <button class=\"btn\" data-dismiss=\"modal\">cancel</button>\n        <button class=\"btn btn-danger x-confirm-delete\">delete</button>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["series/details/episodenumbercell"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <div class=\"row\">\n        <div class=\"key\">Season</div>\n        <div class=\"value\">";
  if (helper = helpers.sceneSeasonNumber) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.sceneSeasonNumber); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</div>\n    </div>\n    ";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <div class=\"row\">\n        <div class=\"key\">Episode</div>\n        <div class=\"value\">";
  if (helper = helpers.sceneEpisodeNumber) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.sceneEpisodeNumber); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</div>\n    </div>\n    ";
  return buffer;
  }

function program5(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <div class=\"row\">\n        <div class=\"key\">Absolute</div>\n        <div class=\"value\">";
  if (helper = helpers.sceneAbsoluteEpisodeNumber) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.sceneAbsoluteEpisodeNumber); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</div>\n    </div>\n    ";
  return buffer;
  }

function program7(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n    <div class=\"row\">\n        ";
  stack1 = (helper = helpers.if_gt || (depth0 && depth0.if_gt),options={hash:{
    'compare': ("1")
  },inverse:self.program(10, program10, data),fn:self.program(8, program8, data),data:data},helper ? helper.call(depth0, ((stack1 = (depth0 && depth0.alternateTitles)),stack1 == null || stack1 === false ? stack1 : stack1.length), options) : helperMissing.call(depth0, "if_gt", ((stack1 = (depth0 && depth0.alternateTitles)),stack1 == null || stack1 === false ? stack1 : stack1.length), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        <div class=\"value\">\n            <ul>\n            ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.alternateTitles), {hash:{},inverse:self.noop,fn:self.program(12, program12, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            </ul>\n        </div>\n    </div>\n    ";
  return buffer;
  }
function program8(depth0,data) {
  
  
  return "\n            <div class=\"key\">Titles</div>\n        ";
  }

function program10(depth0,data) {
  
  
  return "\n            <div class=\"key\">Title</div>\n        ";
  }

function program12(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                <li>";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</li>\n            ";
  return buffer;
  }

  buffer += "<div class=\"scene-info\">\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.sceneSeasonNumber), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.sceneEpisodeNumber), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.sceneAbsoluteEpisodeNumber), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.alternateTitles), {hash:{},inverse:self.noop,fn:self.program(7, program7, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</div>";
  return buffer;
  };
this["T"]["series/details/infoview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  
  return "\n            <span class=\"label label-info\"> 1 file</span>\n        ";
  }

function program3(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n            <span class=\"label label-info\"> ";
  if (helper = helpers.fileCount) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.fileCount); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " files</span>\n        ";
  return buffer;
  }

function program5(depth0,data) {
  
  
  return "\n            <span class=\"label label-info\">Continuing</span>\n        ";
  }

function program7(depth0,data) {
  
  
  return "\n            <span class=\"label label-default\">Ended</span>\n        ";
  }

function program9(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                <a href=\"";
  if (helper = helpers.imdbUrl) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.imdbUrl); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" class=\"label label-info\">IMDB</a>\n            ";
  return buffer;
  }

function program11(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                <a href=\"";
  if (helper = helpers.tvRageUrl) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.tvRageUrl); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" class=\"label label-info\">TV Rage</a>\n            ";
  return buffer;
  }

function program13(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n<div class=\"row\">\n    <div class=\"col-md-12\">\n        ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.alternateTitles), {hash:{},inverse:self.noop,fn:self.program(14, program14, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n</div>\n";
  return buffer;
  }
function program14(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n            ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("-1")
  },inverse:self.noop,fn:self.program(15, program15, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.seasonNumber), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.seasonNumber), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        ";
  return buffer;
  }
function program15(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                <span class=\"label label-default\">";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n            ";
  return buffer;
  }

function program17(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "\n<div class=\"row\">\n    <div class=\"col-md-12\">\n        "
    + escapeExpression((helper = helpers.tagDisplay || (depth0 && depth0.tagDisplay),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.tags), options) : helperMissing.call(depth0, "tagDisplay", (depth0 && depth0.tags), options)))
    + "\n    </div>\n</div>\n";
  return buffer;
  }

  buffer += "<div class=\"row\">\n    <div class=\"col-md-9\">\n        "
    + escapeExpression((helper = helpers.profile || (depth0 && depth0.profile),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.profileId), options) : helperMissing.call(depth0, "profile", (depth0 && depth0.profileId), options)))
    + "\n        <span class=\"label label-info\">";
  if (helper = helpers.network) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.network); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n        <span class=\"label label-info\">";
  if (helper = helpers.runtime) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.runtime); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " minutes</span>\n        <span class=\"label label-info\">";
  if (helper = helpers.path) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.path); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n        <span class=\"label label-info\">"
    + escapeExpression((helper = helpers.Bytes || (depth0 && depth0.Bytes),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.sizeOnDisk), options) : helperMissing.call(depth0, "Bytes", (depth0 && depth0.sizeOnDisk), options)))
    + "</span>\n\n        ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("1")
  },inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.fileCount), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.fileCount), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n        ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("continuing")
  },inverse:self.program(7, program7, data),fn:self.program(5, program5, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.status), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.status), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n    <div class=\"col-md-3\">\n        <span class=\"series-info-links\">\n            <!--<a href=\"";
  if (helper = helpers.traktUrl) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.traktUrl); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" class=\"label label-info\">Trakt</a>-->\n\n            <a href=\"";
  if (helper = helpers.tvdbUrl) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.tvdbUrl); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" class=\"label label-info\">The TVDB</a>\n\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.imdbId), {hash:{},inverse:self.noop,fn:self.program(9, program9, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.tvRageId), {hash:{},inverse:self.noop,fn:self.program(11, program11, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </span>\n    </div>\n</div>\n\n";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.alternateTitles), {hash:{},inverse:self.noop,fn:self.program(13, program13, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.tags), {hash:{},inverse:self.noop,fn:self.program(17, program17, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n";
  return buffer;
  };
this["T"]["series/details/seasonlayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n        Season ";
  if (helper = helpers.seasonNumber) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.seasonNumber); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n        ";
  return buffer;
  }

function program3(depth0,data) {
  
  
  return "\n        Specials\n        ";
  }

function program5(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.monitored), {hash:{},inverse:self.program(8, program8, data),fn:self.program(6, program6, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        ";
  return buffer;
  }
function program6(depth0,data) {
  
  
  return "\n                <span class=\"badge badge-primary season-status\" title=\"No aired episodes\">&nbsp;</span>\n            ";
  }

function program8(depth0,data) {
  
  
  return "\n                <span class=\"badge badge-warning season-status\" title=\"Season is not monitored\">&nbsp;</span>\n            ";
  }

function program10(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n            ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': (100)
  },inverse:self.program(13, program13, data),fn:self.program(11, program11, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.percentOfEpisodes), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.percentOfEpisodes), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        ";
  return buffer;
  }
function program11(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                <span class=\"badge badge-success season-status\" title=\"";
  if (helper = helpers.episodeFileCount) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.episodeFileCount); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/";
  if (helper = helpers.episodeCount) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.episodeCount); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " episodes downloaded\">";
  if (helper = helpers.episodeFileCount) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.episodeFileCount); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " / ";
  if (helper = helpers.episodeCount) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.episodeCount); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n            ";
  return buffer;
  }

function program13(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                <span class=\"badge badge-danger season-status\" title=\"";
  if (helper = helpers.episodeFileCount) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.episodeFileCount); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/";
  if (helper = helpers.episodeCount) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.episodeCount); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " episodes downloaded\">";
  if (helper = helpers.episodeFileCount) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.episodeFileCount); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " / ";
  if (helper = helpers.episodeCount) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.episodeCount); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n            ";
  return buffer;
  }

function program15(depth0,data) {
  
  
  return "\n            <i class=\"icon-chevron-sign-up\"/>\n            Hide Episodes\n            ";
  }

function program17(depth0,data) {
  
  
  return "\n            <i class=\"icon-chevron-sign-down\"/>\n            Show Episodes\n            ";
  }

  buffer += "<div class=\"series-season\" id=\"season-";
  if (helper = helpers.seasonNumber) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.seasonNumber); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n    <h2>\n        <i class=\"x-season-monitored season-monitored clickable\" title=\"Toggle season monitored status\"/>\n\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.seasonNumber), {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n\n        ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': (0)
  },inverse:self.program(10, program10, data),fn:self.program(5, program5, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.episodeCount), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.episodeCount), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n        <span class=\"season-actions pull-right\">\n            <div class=\"x-season-rename\">\n                <i class=\"icon-nd-rename\" title=\"Preview rename for all episodes in season ";
  if (helper = helpers.seasonNumber) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.seasonNumber); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\"/>\n            </div>\n            <div class=\"x-season-search\">\n                <i class=\"icon-search\" title=\"Search for all episodes in season ";
  if (helper = helpers.seasonNumber) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.seasonNumber); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\"/>\n            </div>\n        </span>\n    </h2>\n    <div class=\"show-hide-episodes x-show-hide-episodes\">\n        <h4>\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.showingEpisodes), {hash:{},inverse:self.program(17, program17, data),fn:self.program(15, program15, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </h4>\n    </div>\n    <div class=\"x-episode-grid table-responsive\"></div>\n</div>\n";
  return buffer;
  };
this["T"]["series/details/seriesdetails"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"row series-page-header\">\n    <div class=\"col-md-12\">\n        <div class=\"row\">\n            <h1>\n                <i class=\"x-monitored\" title=\"Toggle monitored state for entire series\"/>\n                ";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n                <div class=\"series-actions pull-right\">\n                    <div class=\"x-refresh\">\n                        <i class=\"icon-refresh icon-can-spin\" title=\"Update series info and scan disk\"/>\n                    </div>\n                    <div class=\"x-rename\">\n                        <i class=\"icon-nd-rename\" title=\"Preview rename for all episodes\"/>\n                    </div>\n                    <div class=\"x-search\">\n                        <i class=\"icon-search\" title=\"Search for all episodes in this series\"/>\n                    </div>\n                    <div class=\"x-edit\">\n                        <i class=\"icon-nd-edit\" title=\"Edit series\"/>\n                    </div>\n                </div>\n            </h1>\n        </div>\n        <div class=\"row series-detail-overview\">\n            ";
  if (helper = helpers.overview) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.overview); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n        </div>\n        <div id=\"info\" class=\"row series-info\"></div>\n    </div>\n</div>\n<div id=\"seasons\"></div>\n";
  return buffer;
  };
this["T"]["series/edit/editseriesview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); partials = this.merge(partials, Handlebars.partials); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                                <option value=\"";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</option>\n                                ";
  return buffer;
  }

  buffer += "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        <h3>";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h3>\n    </div>\n    <div class=\"modal-body edit-series-modal\">\n        <div class=\"row\">\n            <div class=\"col-sm-3 hidden-xs\">\n                ";
  if (helper = helpers.poster) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.poster); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n            </div>\n            <div class=\"col-sm-9\">\n                <div class=\"form-horizontal\">\n\n                    <div class=\"form-group\">\n                        <label class=\"col-sm-4 control-label\">Monitored</label>\n\n                        <div class=\"col-sm-8\">\n                            <div class=\"input-group\">\n                                <label class=\"checkbox toggle well\">\n                                    <input type=\"checkbox\" name=\"monitored\"/>\n                                    <p>\n                                        <span>Yes</span>\n                                        <span>No</span>\n                                    </p>\n\n                                    <div class=\"btn btn-primary slide-button\"/>\n                                </label>\n\n                                <span class=\"help-inline-checkbox\">\n                                    <i class=\"icon-nd-form-info\" title=\"Should Sonarr download episodes for this series?\"/>\n                                </span>\n                            </div>\n                        </div>\n                    </div>\n\n                    <div class=\"form-group\">\n                        <label class=\"col-sm-4 control-label\">Use Season Folder</label>\n\n                        <div class=\"col-sm-8\">\n                            <div class=\"input-group\">\n                                <label class=\"checkbox toggle well\">\n                                    <input type=\"checkbox\" name=\"seasonFolder\"/>\n                                    <p>\n                                        <span>Yes</span>\n                                        <span>No</span>\n                                    </p>\n\n                                    <div class=\"btn btn-primary slide-button\"/>\n                                </label>\n\n                                <span class=\"help-inline-checkbox\">\n                                    <i class=\"icon-nd-form-info\" title=\"Should downloaded episodes be stored in season folders?\"/>\n                                </span>\n                            </div>\n                        </div>\n                    </div>\n\n                    <div class=\"form-group\">\n                        <label class=\"col-sm-4 control-label\">Profile</label>\n\n                        <div class=\"col-sm-4\">\n                            <select class=\"form-control x-profile\" id=\"inputProfile\" name=\"profileId\">\n                                ";
  stack1 = helpers.each.call(depth0, ((stack1 = (depth0 && depth0.profiles)),stack1 == null || stack1 === false ? stack1 : stack1.models), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            </select>\n\n                        </div>\n                    </div>\n\n                    <div class=\"form-group\">\n                        <label class=\"col-sm-4 control-label\">Series Type</label>\n                        <div class=\"col-sm-4\">\n                            ";
  stack1 = self.invokePartial(partials.SeriesTypeSelectionPartial, 'SeriesTypeSelectionPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                        </div>\n                    </div>\n\n                    <div class=\"form-group\">\n                        <label class=\"col-sm-4 control-label\">Path</label>\n\n                        <div class=\"col-sm-6\">\n                            <input type=\"text\" class=\"form-control x-path\" placeholder=\"Path\" name=\"path\">\n                        </div>\n                    </div>\n\n                    <div class=\"form-group\">\n                        <label class=\"col-sm-4 control-label\">Tags</label>\n\n                        <div class=\"col-sm-6\">\n                            <input type=\"text\" class=\"form-control x-tags\">\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </div>\n    <div class=\"modal-footer\">\n        <button class=\"btn btn-danger pull-left x-remove\">delete</button>\n\n        <span class=\"indicator x-indicator\"><i class=\"icon-spinner icon-spin\"></i></span>\n        <button class=\"btn\" data-dismiss=\"modal\">cancel</button>\n        <button class=\"btn btn-primary x-save\">save</button>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["series/editor/serieseditorfooterview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                    <option value=\"";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</option>\n                ";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                <option value=\"";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (helper = helpers.path) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.path); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</option>\n                ";
  return buffer;
  }

  buffer += "<div class=\"series-editor-footer\">\n    <div class=\"row\">\n        <div class=\"form-group col-md-2\">\n            <label>Monitored</label>\n\n            <select class=\"form-control x-monitored\">\n                <option value=\"noChange\">No change</option>\n                <option value=\"true\">Monitored</option>\n                <option value=\"false\">Unmonitored</option>\n            </select>\n        </div>\n\n        <div class=\"form-group col-md-2\">\n            <label>Season Folder</label>\n\n            <select class=\"form-control x-season-folder\">\n                <option value=\"noChange\">No change</option>\n                <option value=\"true\">Yes</option>\n                <option value=\"false\">No</option>\n            </select>\n        </div>\n\n        <div class=\"form-group col-md-2\">\n            <label>Profile</label>\n\n            <select class=\"form-control x-profiles\">\n                <option value=\"noChange\">No change</option>\n                ";
  stack1 = helpers.each.call(depth0, ((stack1 = (depth0 && depth0.profiles)),stack1 == null || stack1 === false ? stack1 : stack1.models), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            </select>\n        </div>\n\n        <div class=\"form-group col-md-3\">\n            <label>Root Folder</label>\n\n            <select class=\"form-control x-root-folder\" validation-name=\"RootFolderPath\">\n                <option value=\"noChange\">No change</option>\n                ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.rootFolders), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                <option value=\"addNew\">Add a different path</option>\n            </select>\n        </div>\n\n        <div class=\"form-group col-md-3 actions\">\n            <label class=\"x-selected-count\">0 series selected</label>\n            <div>\n                <button class=\"btn btn-primary x-save\">Save</button>\n                <button class=\"btn btn-danger x-organize-files\">Organize</button>\n            </div>\n        </div>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["series/editor/serieseditorlayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div id=\"x-toolbar\"></div>\n\n<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div id=\"x-series-editor\" class=\"table-responsive\"></div>\n    </div>\n</div>";
  };
this["T"]["series/index/empty"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"no-series\">\n    <div class=\"row\">\n        <div class=\"well col-md-12\">\n            <i class=\"icon-comment\"/>\n            You must be new around here, You should add some series.\n        </div>\n    </div>\n    <div class=\"row\">\n        <div class=\"col-md-4 col-md-offset-4\">\n            <a href=\"/addseries\" class='btn btn-lg btn-block btn-success x-add-series'>\n                <i class='icon-nd-add'></i>\n                Add Series\n            </a>\n        </div>\n    </div>\n</div>\n";
  };
this["T"]["series/index/footerview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"row\">\n    <div class=\"series-legend legend col-xs-6 col-sm-4\">\n        <ul class='legend-labels'>\n            <li><span class=\"progress-bar\"></span>Continuing (All episodes downloaded)</li>\n            <li><span class=\"progress-bar-success\"></span>Ended (All episodes downloaded)</li>\n            <li><span class=\"progress-bar-danger\"></span>Missing Episodes (Series monitored)</li>\n            <li><span class=\"progress-bar-warning\"></span>Missing Episodes (Series not monitored)</li>\n        </ul>\n    </div>\n    <div class=\"col-xs-5 col-sm-7\">\n        <div class=\"row\">\n            <div class=\"series-stats col-sm-4\">\n                <dl class=\"dl-horizontal\">\n                    <dt>Series</dt>\n                    <dd>";
  if (helper = helpers.series) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.series); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n\n                    <dt>Ended</dt>\n                    <dd>";
  if (helper = helpers.ended) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.ended); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n\n                    <dt>Continuing</dt>\n                    <dd>";
  if (helper = helpers.continuing) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.continuing); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n                </dl>\n            </div>\n\n            <div class=\"series-stats col-sm-4\">\n                <dl class=\"dl-horizontal\">\n                    <dt>Monitored</dt>\n                    <dd>";
  if (helper = helpers.monitored) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.monitored); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n\n                    <dt>Unmonitored</dt>\n                    <dd>";
  if (helper = helpers.unmonitored) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.unmonitored); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n                </dl>\n            </div>\n\n            <div class=\"series-stats col-sm-4\">\n                <dl class=\"dl-horizontal\">\n                    <dt>Episodes</dt>\n                    <dd>";
  if (helper = helpers.episodes) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.episodes); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n\n                    <dt>Files</dt>\n                    <dd>";
  if (helper = helpers.episodeFiles) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.episodeFiles); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n                </dl>\n            </div>\n        </div>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["series/index/seriesindexlayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"toolbars\">\n    <div id=\"x-toolbar\"></div>\n    <div id=\"x-toolbar2\"></div>\n</div>\n\n<div class=\"row\">\n    <div class=\"col-md-12 table-responsive\">\n        <div id=\"x-series\"></div>\n    </div>\n</div>\n\n<div id=\"x-series-footer\"></div>";
  };
this["T"]["settings/downloadclient/downloadclientcollectionview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<fieldset>\n    <legend>Download Clients</legend>\n    <div class=\"row\">\n        <div class=\"col-md-12\">\n            <ul class=\"download-client-list thingies\">\n                <li>\n                    <div class=\"download-client-item thingy add-card x-add-card\">\n                        <span class=\"center well\">\n                            <i class=\"icon-plus\"/>\n                        </span>\n                    </div>\n                </li>\n            </ul>\n        </div>\n    </div>\n</fieldset>";
  };
this["T"]["settings/downloadclient/downloadclientitemview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  
  return "\n            <span class=\"label label-success\">Enabled</span>\n        ";
  }

function program3(depth0,data) {
  
  
  return "\n            <span class=\"label label-default\">Not Enabled</span>\n        ";
  }

  buffer += "<div class=\"download-client-item thingy\">\n    <div>\n        <h3>";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h3>\n    </div>\n\n    <div class=\"settings\">\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.enable), {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["settings/downloadclient/downloadclientlayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div id=\"x-download-clients-region\"></div>\n<div class=\"form-horizontal\">\n    <div id=\"x-download-handling-region\"></div>\n    <div id=\"x-dronefactory-region\"></div>\n    <div id=\"x-remotepath-mapping-region\"></div>\n</div>\n";
  };
this["T"]["settings/general/generalview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, self=this, functionType="function", blockHelperMissing=helpers.blockHelperMissing;

function program1(depth0,data) {
  
  
  return "\n            <div class=\"form-group advanced-setting\">\n                <label class=\"col-sm-3 control-label\">SSL Cert Hash</label>\n\n                <div class=\"col-sm-4\">\n                    <input type=\"text\" name=\"sslCertHash\" class=\"form-control\"/>\n                </div>\n            </div>\n            ";
  }

function program3(depth0,data) {
  
  
  return "\n        <div class=\"alert alert-warning\">Please see: <a href=\"https://github.com/NzbDrone/NzbDrone/wiki/Updating\">the wiki</a> for more information</div>\n\n        <div class=\"form-group\">\n            <label class=\"col-sm-3 control-label\">Automatic</label>\n\n            <div class=\"col-sm-8\">\n                <div class=\"input-group\">\n                    <label class=\"checkbox toggle well\">\n                        <input type=\"checkbox\" name=\"updateAutomatically\"/>\n                        <p>\n                            <span>On</span>\n                            <span>Off</span>\n                        </p>\n                        <div class=\"btn btn-primary slide-button\"/>\n                    </label>\n\n                    <span class=\"help-inline-checkbox\">\n                        <i class=\"icon-nd-form-info\" title=\"Automatically download and install updates. You will still be able to install from System: Updates\"/>\n                    </span>\n                </div>\n            </div>\n        </div>\n\n        <div class=\"form-group\">\n            <label class=\"col-sm-3 control-label\">Mechanism</label>\n\n            <div class=\"col-sm-1 col-sm-push-4 help-inline\">\n                <i class=\"icon-nd-form-info\" title=\"Use built-in updater or external script\"/>\n            </div>\n\n            <div class=\"col-sm-4 col-sm-pull-1\">\n                <select name=\"updateMechanism\" class=\"form-control x-update-mechanism\">\n                    <option value=\"builtIn\">Built-in</option>\n                    <option value=\"script\">Script</option>\n                </select>\n            </div>\n        </div>\n\n        <div class=\"form-group x-script-group\">\n            <label class=\"col-sm-3 control-label\">Script Path</label>\n\n            <div class=\"col-sm-1 col-sm-push-4 help-inline\">\n                <i class=\"icon-nd-form-info\" title=\"Path to a custom script that take an extracted update package and handle the remainder of the update process\"/>\n            </div>\n\n            <div class=\"col-sm-4 col-sm-pull-1\">\n                <input type=\"text\" name=\"updateScriptPath\" class=\"form-control\"/>\n            </div>\n        </div>\n        ";
  }

  buffer += "<div class=\"form-horizontal\">\n    <fieldset>\n        <legend>Start-Up</legend>\n\n        <div class=\"form-group advanced-setting\">\n            <label class=\"col-sm-3 control-label\">Bind Address</label>\n\n            <div class=\"col-sm-1 col-sm-push-4 help-inline\">\n                <i class=\"icon-nd-form-warning\" title=\"Requires restart to take effect\" />\n                <i class=\"icon-nd-form-info\" title=\"Valid IP4 address or '*' for all interfaces\"/>\n            </div>\n\n            <div class=\"col-sm-4 col-sm-pull-1\">\n                <input type=\"text\" placeholder=\"*\" name=\"bindAddress\" class=\"form-control\" />\n            </div>\n        </div>\n\n        <div class=\"form-group\">\n            <label class=\"col-sm-3 control-label\">Port Number</label>\n\n            <div class=\"col-sm-1 col-sm-push-4 help-inline\">\n                <i class=\"icon-nd-form-warning\" title=\"Requires restart to take effect\"/>\n            </div>\n\n            <div class=\"col-sm-4 col-sm-pull-1\">\n                <input type=\"number\" placeholder=\"8989\" name=\"port\" class=\"form-control\"/>\n            </div>\n        </div>\n\n        <div class=\"form-group\">\n            <label class=\"col-sm-3 control-label\">URL Base</label>\n\n            <div class=\"col-sm-1 col-sm-push-4 help-inline\">\n                <i class=\"icon-nd-form-warning\" title=\"Requires restart to take effect\"/>\n                <i class=\"icon-nd-form-info\" title=\"For reverse proxy support, default is empty\"/>\n            </div>\n\n            <div class=\"col-sm-4 col-sm-pull-1\">\n                <input type=\"text\" name=\"urlBase\" class=\"form-control\"/>\n            </div>\n        </div>\n\n        <div class=\"form-group advanced-setting\">\n            <label class=\"col-sm-3 control-label\">Enable SSL</label>\n\n            <div class=\"col-sm-8\">\n                <div class=\"input-group\">\n                    <label class=\"checkbox toggle well\">\n                        <input type=\"checkbox\" name=\"enableSsl\" class=\"x-ssl\"/>\n\n                        <p>\n                            <span>Yes</span>\n                            <span>No</span>\n                        </p>\n\n                        <div class=\"btn btn-primary slide-button\"/>\n                    </label>\n\n                    <span class=\"help-inline-checkbox\">\n                        <i class=\"icon-nd-form-warning\" title=\"Requires restart running as administrator to take effect\"/>\n                    </span>\n                </div>\n            </div>\n        </div>\n\n        <div class=\"x-ssl-options\">\n            <div class=\"form-group advanced-setting\">\n                <label class=\"col-sm-3 control-label\">SSL Port Number</label>\n\n                <div class=\"col-sm-4\">\n                    <input type=\"number\" placeholder=\"8989\" name=\"sslPort\" class=\"form-control\"/>\n                </div>\n            </div>\n\n            ";
  options={hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data}
  if (helper = helpers.if_windows) { stack1 = helper.call(depth0, options); }
  else { helper = (depth0 && depth0.if_windows); stack1 = typeof helper === functionType ? helper.call(depth0, options) : helper; }
  if (!helpers.if_windows) { stack1 = blockHelperMissing.call(depth0, stack1, {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data}); }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </div>\n\n        <div class=\"form-group\">\n            <label class=\"col-sm-3 control-label\">Open browser on start</label>\n\n            <div class=\"col-sm-8\">\n                <div class=\"input-group\">\n                    <label class=\"checkbox toggle well\">\n                        <input type=\"checkbox\" name=\"launchBrowser\" class=\"form-control\"/>\n\n                        <p>\n                            <span>Yes</span>\n                            <span>No</span>\n                        </p>\n\n                        <div class=\"btn btn-primary slide-button\"/>\n                    </label>\n\n                    <span class=\"help-inline-checkbox\">\n                        <i class=\"icon-nd-form-info\" title=\"Open a web browser and navigate to Sonarr homepage on app start. Has no effect if installed as a windows service\"/>\n                    </span>\n                </div>\n            </div>\n        </div>\n    </fieldset>\n\n    <fieldset>\n        <legend>Security</legend>\n        <div class=\"form-group\">\n            <label class=\"col-sm-3 control-label\">Authentication</label>\n\n            <div class=\"col-sm-8\">\n                <div class=\"input-group\">\n                    <label class=\"checkbox toggle well\">\n                        <input type=\"checkbox\" class=\"x-auth\" name=\"authenticationEnabled\"/>\n                        <p>\n                            <span>On</span>\n                            <span>Off</span>\n                        </p>\n                        <div class=\"btn btn-primary slide-button\"/>\n                    </label>\n\n                    <span class=\"help-inline-checkbox\">\n                        <i class=\"icon-nd-form-info\" title=\"Require Username and Password to access Sonarr\"/>\n                    </span>\n                </div>\n            </div>\n        </div>\n\n        <div class=\"x-auth-options\">\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Username</label>\n\n                <div class=\"col-sm-4\">\n                    <input type=\"text\" placeholder=\"Username\" name=\"username\" class=\"form-control\"/>\n                </div>\n            </div>\n\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Password</label>\n\n                <div class=\"col-sm-4\">\n                    <input type=\"password\" name=\"password\" class=\"form-control\"/>\n                </div>\n            </div>\n        </div>\n\n        <div class=\"form-group api-key\">\n            <label class=\"col-sm-3 control-label\">API Key</label>\n\n            <div class=\"col-sm-1 col-sm-push-4 help-inline\">\n                <i class=\"icon-nd-form-warning\" title=\"Requires restart to take effect\"/>\n            </div>\n\n            <div class=\"col-sm-4 col-sm-pull-1\">\n                <div class=\"input-group\">\n                    <input type=\"text\" name=\"apiKey\" readonly=\"readonly\" class=\"form-control x-api-key\"/>\n                    <div class=\"input-group-btn\">\n                        <button class=\"btn btn-icon-only x-copy-api-key hidden-xs\"><i class=\"icon-copy\"></i></button>\n                        <button class=\"btn btn-danger btn-icon-only x-reset-api-key\" title=\"Reset API Key\"><i class=\"icon-refresh\"></i></button>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </fieldset>\n\n    <fieldset>\n        <legend>Logging</legend>\n\n        <div class=\"form-group\">\n            <label class=\"col-sm-3 control-label\">Log Level</label>\n\n            <div class=\"col-sm-1 col-sm-push-2 help-inline\">\n                <i class=\"icon-nd-form-warning\" title=\"Trace logging should only be enabled temporarily\"/>\n            </div>\n\n            <div class=\"col-sm-2 col-sm-pull-1\">\n                <select name=\"logLevel\" class=\"form-control\">\n                    <option value=\"Trace\">Trace</option>\n                    <option value=\"Debug\">Debug</option>\n                    <option value=\"Info\">Info</option>\n                </select>\n            </div>\n        </div>\n    </fieldset>\n    <fieldset>\n        <legend>Analytics</legend>\n\n        <div class=\"form-group\">\n            <label class=\"col-sm-3 control-label\">Enable</label>\n\n            <div class=\"col-sm-8\">\n                <div class=\"input-group\">\n                    <label class=\"checkbox toggle well\">\n                        <input type=\"checkbox\" name=\"analyticsEnabled\" class=\"form-control\"/>\n                        <p>\n                            <span>Yes</span>\n                            <span>No</span>\n                        </p>\n                        <div class=\"btn btn-primary slide-button\"/>\n                    </label>\n\n                    <span class=\"help-inline-checkbox\">\n                        <i class=\"icon-nd-form-info\" title=\"Send anonymous information about your browser and which parts of the web interface you use to Sonarr servers. We use this information to prioritize features and browser support. We will NEVER include any personal information or any information that could identify you.\"/>\n                        <i class=\"icon-nd-form-warning\" title=\"Requires restart to take effect\"/>\n                    </span>\n                </div>\n            </div>\n        </div>\n    </fieldset>\n\n    <fieldset class=\"advanced-setting\">\n        <legend>Updates</legend>\n\n        <div class=\"form-group\">\n            <label class=\"col-sm-3 control-label\">Branch</label>\n\n            <div class=\"col-sm-4\">\n                <input type=\"text\" placeholder=\"master\" name=\"branch\" class=\"form-control\"/>\n            </div>\n        </div>\n\n        ";
  options={hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data}
  if (helper = helpers.if_mono) { stack1 = helper.call(depth0, options); }
  else { helper = (depth0 && depth0.if_mono); stack1 = typeof helper === functionType ? helper.call(depth0, options) : helper; }
  if (!helpers.if_mono) { stack1 = blockHelperMissing.call(depth0, stack1, {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data}); }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </fieldset>\n</div>\n";
  return buffer;
  };
this["T"]["settings/indexers/indexercollectionview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<fieldset>\n    <legend>Indexers</legend>\n    <div class=\"row\">\n        <div class=\"col-md-12\">\n            <ul class=\"indexer-list thingies\">\n                <li>\n                    <div class=\"indexer-item thingy add-card x-add-card\">\n                        <span class=\"center well\">\n                            <i class=\"icon-plus\"/>\n                        </span>\n                    </div>\n                </li>\n            </ul>\n        </div>\n    </div>\n</fieldset>";
  };
this["T"]["settings/indexers/indexeritemview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, self=this, functionType="function", escapeExpression=this.escapeExpression;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.enableRss), {hash:{},inverse:self.program(4, program4, data),fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        ";
  return buffer;
  }
function program2(depth0,data) {
  
  
  return "\n                <span class=\"label label-success\">RSS</span>\n            ";
  }

function program4(depth0,data) {
  
  
  return "\n                <span class=\"label label-default\">RSS</span>\n            ";
  }

function program6(depth0,data) {
  
  
  return "\n            <span class=\"label label-default label-disabled\">RSS</span>\n        ";
  }

function program8(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.enableSearch), {hash:{},inverse:self.program(11, program11, data),fn:self.program(9, program9, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        ";
  return buffer;
  }
function program9(depth0,data) {
  
  
  return "\n                <span class=\"label label-success\">Search</span>\n            ";
  }

function program11(depth0,data) {
  
  
  return "\n                <span class=\"label label-default\">Search</span>\n            ";
  }

function program13(depth0,data) {
  
  
  return "\n            <span class=\"label label-default label-disabled\">Search</span>\n        ";
  }

  buffer += "<div class=\"indexer-item thingy\">\n    <div>\n        <h3>";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h3>\n    </div>\n\n    <div class=\"settings\">\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.supportsRss), {hash:{},inverse:self.program(6, program6, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.supportsSearch), {hash:{},inverse:self.program(13, program13, data),fn:self.program(8, program8, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["settings/indexers/indexerlayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div id=\"x-indexers-region\"></div>\n<div class=\"form-horizontal\">\n    <div id=\"x-indexer-options-region\"></div>\n    <div id=\"x-restriction-region\"></div>\n</div>\n";
  };
this["T"]["settings/mediamanagement/mediamanagementlayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, self=this, functionType="function", blockHelperMissing=helpers.blockHelperMissing;

function program1(depth0,data) {
  
  
  return "<div id=\"permissions\"></div>";
  }

  buffer += "<div class=\"form-horizontal\">\n    <div id=\"episode-naming\"></div>\n    <div id=\"sorting\"></div>\n    <div id=\"file-management\"></div>\n    ";
  options={hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data}
  if (helper = helpers.if_mono) { stack1 = helper.call(depth0, options); }
  else { helper = (depth0 && depth0.if_mono); stack1 = typeof helper === functionType ? helper.call(depth0, options) : helper; }
  if (!helpers.if_mono) { stack1 = blockHelperMissing.call(depth0, stack1, {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data}); }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</div>";
  return buffer;
  };
this["T"]["settings/metadata/metadatacollectionview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<fieldset>\n    <legend>Metadata</legend>\n    <div class=\"row\">\n        <div class=\"col-md-12\">\n            <ul id=\"x-metadata\" class=\"metadata-list\"></ul>\n        </div>\n    </div>\n</fieldset>";
  };
this["T"]["settings/metadata/metadataeditview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        <h3>Edit</h3>\n    </div>\n    <div class=\"modal-body\">\n        <div class=\"form-horizontal\">\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Name</label>\n\n                <div class=\"col-sm-5 controls\">\n                    <input type=\"text\" name=\"name\" class=\"form-control\"/>\n                </div>\n            </div>\n\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Enable</label>\n\n                <div class=\"col-sm-5\">\n                    <div class=\"input-group\">\n                        <label class=\"checkbox toggle well\">\n                            <input type=\"checkbox\" name=\"enable\"/>\n                            <p>\n                                <span>Yes</span>\n                                <span>No</span>\n                            </p>\n\n                            <div class=\"btn btn-primary slide-button\"/>\n                        </label>\n                    </div>\n                </div>\n            </div>\n\n            ";
  if (helper = helpers.formBuilder) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.formBuilder); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n        </div>\n    </div>\n    <div class=\"modal-footer\">\n        <span class=\"indicator x-indicator\"><i class=\"icon-spinner icon-spin\"></i></span>\n\n        <button class=\"btn\" data-dismiss=\"modal\">cancel</button>\n        <button class=\"btn btn-primary x-save\">save</button>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["settings/metadata/metadataitemview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  
  return "\n            <span class=\"label label-success\">Enabled</span>\n        ";
  }

function program3(depth0,data) {
  
  
  return "\n            <span class=\"label label-default\">Not Enabled</span>\n        ";
  }

function program5(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n            ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("checkbox")
  },inverse:self.noop,fn:self.program(6, program6, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.type), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.type), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        ";
  return buffer;
  }
function program6(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.value), {hash:{},inverse:self.program(9, program9, data),fn:self.program(7, program7, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            ";
  return buffer;
  }
function program7(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                    <span class=\"label label-success\">";
  if (helper = helpers.label) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.label); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n                ";
  return buffer;
  }

function program9(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                    <span class=\"label\">";
  if (helper = helpers.label) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.label); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n                ";
  return buffer;
  }

  buffer += "<div class=\"metadata-item\">\n    <div>\n        <h3>";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h3>\n    </div>\n\n    <div class=\"settings\">\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.enable), {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        <hr>\n        ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.fields), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["settings/metadata/metadatalayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"row\">\n    <div class=\"col-md-12\" id=\"x-metadata-providers\"/>\n</div>\n";
  };
this["T"]["settings/notifications/notificationcollectionview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<fieldset>\n    <legend>Connections</legend>\n    <div class=\"row\">\n        <div class=\"col-md-12\">\n            <ul class=\"notification-list thingies\">\n                <li>\n                    <div class=\"notification-item thingy add-card x-add-card\">\n                        <span class=\"center well\">\n                            <i class=\"icon-plus\"/>\n                        </span>\n                    </div>\n                </li>\n            </ul>\n        </div>\n    </div>\n</fieldset>";
  };
this["T"]["settings/notifications/notificationitemview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  
  return "\n            <span class=\"label label-success\">On Grab</span>\n        ";
  }

function program3(depth0,data) {
  
  
  return "\n            <span class=\"label label-default\">On Grab</span>\n        ";
  }

function program5(depth0,data) {
  
  
  return "\n            <span class=\"label label-success\">On Download</span>\n        ";
  }

function program7(depth0,data) {
  
  
  return "\n            <span class=\"label label-default\">On Download</span>\n        ";
  }

  buffer += "<div class=\"notification-item thingy\">\n    <div>\n        <h3>";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h3>\n    </div>\n\n    <div class=\"settings\">\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.onGrab), {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.onDownload), {hash:{},inverse:self.program(7, program7, data),fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["settings/profile/deleteprofileview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"modal-content\">\n    ﻿<div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        <h3>Delete: ";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h3>\n    </div>\n    <div class=\"modal-body\">\n        <p>Are you sure you want to delete '";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "'?</p>\n    </div>\n    <div class=\"modal-footer\">\n        <button class=\"btn\" data-dismiss=\"modal\">cancel</button>\n        <button class=\"btn btn-danger x-confirm-delete\">delete</button>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["settings/profile/profilecollection"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<fieldset>\n    <legend>Profiles</legend>\n    <div class=\"row\">\n        <div class=\"col-md-12\">\n            <ul class=\"profiles thingies\">\n                <li>\n                    <div class=\"profile-item thingy add-card x-add-card\">\n                        <span class=\"center well\">\n                            <i class=\"icon-plus\"/>\n                        </span>\n                    </div>\n                </li>\n            </ul>\n        </div>\n    </div>\n</fieldset>";
  };
this["T"]["settings/profile/profilelayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"row\">\n    <div class=\"col-md-12\" id=\"profile\"/>\n\n    <div class=\"col-md-12 delay-profile-region\" id=\"delay-profile\"/>\n</div>\n";
  };
this["T"]["settings/profile/profileview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"profile-item thingy\">\n    <div>\n        <h3 name=\"name\"></h3>\n    </div>\n\n    <div class=\"language\">\n        ";
  if (helper = helpers.languageLabel) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.languageLabel); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n    </div>\n\n    <ul class=\"allowed-qualities\">\n        ";
  if (helper = helpers.allowedLabeler) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.allowedLabeler); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n    </ul>\n</div>";
  return buffer;
  };
this["T"]["settings/quality/qualitylayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"row\">\n    <div class=\"col-md-12\" id=\"quality-definition\"/>\n</div>\n";
  };
this["T"]["settings/ui/uiview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"form-horizontal\">\n    <fieldset>\n        <legend>Calendar</legend>\n\n        <div class=\"form-group\">\n            <label class=\"col-sm-3 control-label\">First Day of Week</label>\n\n            <div class=\"col-sm-4\">\n                <select name=\"firstDayOfWeek\" class=\"form-control\">\n                    <option value=\"0\">Sunday</option>\n                    <option value=\"1\">Monday</option>\n                </select>\n            </div>\n        </div>\n\n        <div class=\"form-group\">\n            <label class=\"col-sm-3 control-label\">Week Column Header</label>\n\n            <div class=\"col-sm-1 col-sm-push-4 help-inline\">\n                <i class=\"icon-nd-form-info\" title=\"Shown above each column when week is the active view\"/>\n            </div>\n\n            <div class=\"col-sm-4 col-sm-pull-1\">\n                <select name=\"calendarWeekColumnHeader\" class=\"form-control\">\n                    <option value=\"ddd M/D\">Tue 3/25</option>\n                    <option value=\"ddd MM/DD\">Tue 03/25</option>\n                    <option value=\"ddd D/M\">Tue 25/3</option>\n                    <option value=\"ddd DD/MM\">Tue 25/03</option>\n                </select>\n            </div>\n        </div>\n    </fieldset>\n\n    <fieldset>\n        <legend>Dates</legend>\n\n        <div class=\"form-group\">\n            <label class=\"col-sm-3 control-label\">Short Date Format</label>\n\n            <div class=\"col-sm-4\">\n                <select name=\"shortDateFormat\" class=\"form-control\">\n                    <option value=\"MMM D YYYY\">Mar 5 2014</option>\n                    <option value=\"DD MMM YYYY\">5 Mar 2014</option>\n                    <option value=\"MM/D/YYYY\">03/5/2014</option>\n                    <option value=\"MM/DD/YYYY\">03/05/2014</option>\n                    <option value=\"DD/MM/YYYY\">25/03/2014</option>\n                    <option value=\"YYYY-MM-DD\">2014-03-05</option>\n                </select>\n            </div>\n        </div>\n\n        <div class=\"form-group\">\n            <label class=\"col-sm-3 control-label\">Long Date Format</label>\n\n            <div class=\"col-sm-4\">\n                <select name=\"longDateFormat\" class=\"form-control\">\n                    <option value=\"dddd, MMMM D YYYY\">Tuesday, March 25, 2014</option>\n                    <option value=\"dddd, D MMMM YYYY\">Tuesday, 25 March, 2014</option>\n                </select>\n            </div>\n        </div>\n\n        <div class=\"form-group\">\n            <label class=\"col-sm-3 control-label\">Time Format</label>\n\n            <div class=\"col-sm-4\">\n                <select name=\"timeFormat\" class=\"form-control\">\n                    <option value=\"h(:mm)a\">5pm/5:30pm</option>\n                    <option value=\"HH:mm\">17:00/17:30</option>\n                </select>\n            </div>\n        </div>\n\n        <div class=\"form-group\">\n            <label class=\"col-sm-3 control-label\">Show Relative Dates</label>\n\n            <div class=\"col-sm-8\">\n                <div class=\"input-group\">\n                    <label class=\"checkbox toggle well\">\n                        <input type=\"checkbox\" name=\"showRelativeDates\"/>\n\n                        <p>\n                            <span>Yes</span>\n                            <span>No</span>\n                        </p>\n\n                        <div class=\"btn btn-primary slide-button\"/>\n                    </label>\n\n                    <span class=\"help-inline-checkbox\">\n                        <i class=\"icon-nd-form-info\" title=\"Show relative (Today/Yesterday/etc) or absolute dates\"/>\n                    </span>\n                </div>\n            </div>\n        </div>\n    </fieldset>\n</div>\n";
  };
this["T"]["shared/filebrowser/emptyview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"text-center col-md-12 file-browser-empty\">\n    <span>No files/folders were found, edit the path above, or clear to start again</span>\n</div>\n";
  };
this["T"]["shared/filebrowser/filebrowserlayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n    <button type=\"button\" class=\"close\" aria-hidden=\"true\" data-dismiss=\"modal\">&times;</button>\n    <h3>File Browser</h3>\n</div>\n    <div class=\"modal-body\">\n        <div class=\"row\">\n            <div class=\"col-sm-12\">\n                <div class=\"form-group\">\n                    <input type=\"text\" class=\"form-control x-path\" placeholder=\"Start typing or select a path below\"/>\n                </div>\n            </div>\n        </div>\n\n        <div class=\"row\">\n            <div class=\"col-sm-12\">\n                <div id=\"x-browser\"></div>\n            </div>\n        </div>\n    </div>\n    <div class=\"modal-footer\">\n        <span class=\"indicator x-indicator\"><i class=\"icon-spinner icon-spin\"></i></span>\n        <button class=\"btn\" data-dismiss=\"modal\">close</button>\n        <button class=\"btn btn-primary x-ok\">ok</button>\n    </div>\n</div>\n";
  };
this["T"]["shared/grid/jumptopage"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.current), {hash:{},inverse:self.program(4, program4, data),fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n            <option value=\"";
  if (helper = helpers.page) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.page); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" selected=\"selected\">";
  if (helper = helpers.page) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.page); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</option>\n        ";
  return buffer;
  }

function program4(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n            <option value=\"";
  if (helper = helpers.page) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.page); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (helper = helpers.page) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.page); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</option>\n        ";
  return buffer;
  }

  buffer += "<select class=\"x-page-select\">\n    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.pages), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</select>";
  return buffer;
  };
this["T"]["shared/grid/pager"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n        <li ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.className), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += " >\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.pageNumber), {hash:{},inverse:self.program(6, program6, data),fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </li>\n    ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "class=\"";
  if (helper = helpers.className) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.className); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\"";
  return buffer;
  }

function program4(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                <span class=\"x-page-number\">";
  if (helper = helpers.pageNumber) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.pageNumber); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " / ";
  if (helper = helpers.lastPage) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.lastPage); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n            ";
  return buffer;
  }

function program6(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n            <i class=\"pager-btn clickable ";
  if (helper = helpers.label) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.label); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" data-action=\"";
  if (helper = helpers.action) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.action); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\"/>\n            ";
  return buffer;
  }

  buffer += "<ul>\n    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.handles), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</ul>\n\n<span class=\"total-records\">\n    <span class=\"hidden-xs\">Total records: "
    + escapeExpression((helper = helpers.Number || (depth0 && depth0.Number),options={hash:{},data:data},helper ? helper.call(depth0, ((stack1 = (depth0 && depth0.state)),stack1 == null || stack1 === false ? stack1 : stack1.totalRecords), options) : helperMissing.call(depth0, "Number", ((stack1 = (depth0 && depth0.state)),stack1 == null || stack1 === false ? stack1 : stack1.totalRecords), options)))
    + "</span>\n    <span class=\"visible-xs label label-info\" title=\"Total records\">"
    + escapeExpression((helper = helpers.Number || (depth0 && depth0.Number),options={hash:{},data:data},helper ? helper.call(depth0, ((stack1 = (depth0 && depth0.state)),stack1 == null || stack1 === false ? stack1 : stack1.totalRecords), options) : helperMissing.call(depth0, "Number", ((stack1 = (depth0 && depth0.state)),stack1 == null || stack1 === false ? stack1 : stack1.totalRecords), options)))
    + "</span>\n</span>";
  return buffer;
  };
this["T"]["shared/toolbar/button"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<i class=\"";
  if (helper = helpers.icon) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.icon); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " x-icon\"/><span> ";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n";
  return buffer;
  };
this["T"]["shared/toolbar/radiobutton"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<input type=\"radio\"><i class=\"";
  if (helper = helpers.icon) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.icon); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " x-icon\"/><span> ";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n";
  return buffer;
  };
this["T"]["shared/toolbar/toolbarlayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"page-toolbar pull-left pull-none-xs x-toolbar-left\" />\n<div class=\"page-toolbar pull-right pull-none-xs x-toolbar-right\" />\n";
  };
this["T"]["system/backup/backupemptyview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div>No backups are available</div>";
  };
this["T"]["system/backup/backupfilenamecell"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<a href=\"";
  if (helper = helpers.UrlBase) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.UrlBase); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/backup/";
  if (helper = helpers.type) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.type); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" class=\"no-router\">";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</a>\n";
  return buffer;
  };
this["T"]["system/backup/backuplayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div id=\"x-backup-toolbar\"/>\n    </div>\n</div>\n<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div id=\"x-backups\" class=\"table-responsive\"/>\n    </div>\n</div>\n";
  };
this["T"]["system/info/systeminfolayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"row\">\n    <div class=\"col-md-12\" id=\"health\"></div>\n</div>\n\n<div class=\"row\">\n    <div class=\"col-md-12\" id=\"diskspace\"></div>\n</div>\n\n<div class=\"row\">\n    <div class=\"col-md-12\" id=\"about\"></div>\n</div>\n\n<div class=\"row\">\n    <div class=\"col-md-12\" id=\"more-info\"></div>\n</div>\n";
  };
this["T"]["system/logs/logslayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"row\">\n    <div class=\"col-md-2 col-sm-2\">\n        <ul class=\"nav nav-pills nav-stacked\">\n            <li><a href=\"#table\" class=\"x-table-tab no-router\">Table</a></li>\n            <li><a href=\"#files\" class=\"x-files-tab no-router\">Files</a></li>\n            <li><a href=\"#update-files\" class=\"x-update-files-tab no-router\">Updates</a></li>\n        </ul>\n    </div>\n\n    <div class=\"col-md-10 col-sm-10\">\n        <div class=\"tab-content\">\n            <div class=\"tab-pane\" id=\"table\"></div>\n            <div class=\"tab-pane\" id=\"files\"></div>\n            <div class=\"tab-pane\" id=\"update-files\"></div>\n        </div>\n    </div>\n</div>";
  };
this["T"]["system/task/tasklayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div id=\"x-tasks\" class=\"tasks table-responsive\"/>\n    </div>\n</div>\n";
  };
this["T"]["system/update/emptyview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div>No updates are available</div>";
  };
this["T"]["system/update/updateitemview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, self=this, functionType="function", escapeExpression=this.escapeExpression, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  
  return "\n                    <span class=\"label label-success\">Installed</span>\n                ";
  }

function program3(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n                    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.latest), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                ";
  return buffer;
  }
function program4(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n                        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.installable), {hash:{},inverse:self.program(7, program7, data),fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                    ";
  return buffer;
  }
function program5(depth0,data) {
  
  
  return "\n                            <span class=\"label label-default install-update x-install-update\">Install</span>\n                        ";
  }

function program7(depth0,data) {
  
  
  return "\n                            <span class=\"label label-default label-disabled\" title=\"Cannot install an older version\">Install</span>\n                        ";
  }

function program9(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n            ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0['new']), {hash:{},inverse:self.noop,fn:self.program(10, program10, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n            ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.fixed), {hash:{},inverse:self.noop,fn:self.program(12, program12, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        ";
  return buffer;
  }
function program10(depth0,data) {
  
  var buffer = "";
  buffer += "\n                <div class=\"change\">\n                    <span class=\"label label-success\">New</span> "
    + escapeExpression((typeof depth0 === functionType ? depth0.apply(depth0) : depth0))
    + "\n                </div>\n            ";
  return buffer;
  }

function program12(depth0,data) {
  
  var buffer = "";
  buffer += "\n                <div class=\"change\">\n                    <span class=\"label label-info\">Fixed</span> "
    + escapeExpression((typeof depth0 === functionType ? depth0.apply(depth0) : depth0))
    + "\n                </div>\n            ";
  return buffer;
  }

function program14(depth0,data) {
  
  
  return "\n            Maintenance release\n        ";
  }

  buffer += "<div class=\"update\">\n    <fieldset>\n        <legend>";
  if (helper = helpers.version) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.version); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n            <span class=\"date\">\n                - "
    + escapeExpression((helper = helpers.ShortDate || (depth0 && depth0.ShortDate),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.releaseDate), options) : helperMissing.call(depth0, "ShortDate", (depth0 && depth0.releaseDate), options)))
    + "\n            </span>\n            <span class=\"status\">\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.installed), {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            </span>\n        </legend>\n\n        ";
  stack1 = helpers['with'].call(depth0, (depth0 && depth0.changes), {hash:{},inverse:self.noop,fn:self.program(9, program9, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n        ";
  stack1 = helpers.unless.call(depth0, (depth0 && depth0.changes), {hash:{},inverse:self.noop,fn:self.program(14, program14, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </fieldset>\n</div>\n";
  return buffer;
  };
this["T"]["system/update/updatelayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div id=\"x-updates\"/>\n    </div>\n</div>\n";
  };
this["T"]["wanted/cutoff/cutoffunmetlayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div id=\"x-toolbar\"/>\n<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div id=\"x-cutoff-unmet\"/>\n    </div>\n</div>\n<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div id=\"x-pager\"/>\n    </div>\n</div>\n";
  };
this["T"]["wanted/missing/missinglayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div id=\"x-toolbar\"/>\n<div class=\"row\">\n    <div class=\"col-md-12 table-responsive\">\n        <div id=\"x-missing\"/>\n    </div>\n</div>\n<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div id=\"x-pager\"/>\n    </div>\n</div>\n";
  };
this["T"]["activity/history/details/historydetailslayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  
  return "Grabbed";
  }

function program3(depth0,data) {
  
  
  return "Download Failed";
  }

function program5(depth0,data) {
  
  
  return "Episode Imported";
  }

function program7(depth0,data) {
  
  
  return "Episode File Deleted";
  }

function program9(depth0,data) {
  
  
  return "<button class=\"btn btn-danger x-mark-as-failed\">mark as failed</button>";
  }

  buffer += "<div class=\"modal-content\">\n    <div class=\"history-detail-modal\">\n        <div class=\"modal-header\">\n            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n\n            <h3>\n                ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("grabbed")
  },inverse:self.noop,fn:self.program(1, program1, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.eventType), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.eventType), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("downloadFailed")
  },inverse:self.noop,fn:self.program(3, program3, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.eventType), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.eventType), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("downloadFolderImported")
  },inverse:self.noop,fn:self.program(5, program5, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.eventType), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.eventType), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("episodeFileDeleted")
  },inverse:self.noop,fn:self.program(7, program7, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.eventType), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.eventType), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            </h3>\n\n        </div>\n        <div class=\"modal-body\">\n\n        </div>\n        <div class=\"modal-footer\">\n            ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("grabbed")
  },inverse:self.noop,fn:self.program(9, program9, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.eventType), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.eventType), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            <button class=\"btn\" data-dismiss=\"modal\">close</button>\n        </div>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["activity/history/details/historydetailsview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, helperMissing=helpers.helperMissing, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n<dl class=\"dl-horizontal info\">\n\n    <dt>Name:</dt>\n    <dd>";
  if (helper = helpers.sourceTitle) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.sourceTitle); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n\n    ";
  stack1 = helpers['with'].call(depth0, (depth0 && depth0.data), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</dl>\n";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.indexer), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.releaseGroup), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.nzbInfoUrl), {hash:{},inverse:self.noop,fn:self.program(7, program7, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.downloadClient), {hash:{},inverse:self.noop,fn:self.program(9, program9, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.downloadId), {hash:{},inverse:self.noop,fn:self.program(11, program11, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.age), {hash:{},inverse:self.noop,fn:self.program(13, program13, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.publishedDate), {hash:{},inverse:self.noop,fn:self.program(15, program15, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    ";
  return buffer;
  }
function program3(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <dt>Indexer:</dt>\n    <dd>";
  if (helper = helpers.indexer) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.indexer); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n    ";
  return buffer;
  }

function program5(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <dt>Release Group:</dt>\n    <dd>";
  if (helper = helpers.releaseGroup) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.releaseGroup); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n    ";
  return buffer;
  }

function program7(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <dt>Info:</dt>\n    <dd><a href=\"";
  if (helper = helpers.nzbInfoUrl) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.nzbInfoUrl); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (helper = helpers.nzbInfoUrl) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.nzbInfoUrl); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</a></dd>\n    ";
  return buffer;
  }

function program9(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <dt>Download Client:</dt>\n    <dd>";
  if (helper = helpers.downloadClient) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.downloadClient); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n    ";
  return buffer;
  }

function program11(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <dt>Grab ID:</dt>\n    <dd>";
  if (helper = helpers.downloadId) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.downloadId); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n    ";
  return buffer;
  }

function program13(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    ";
  if (helper = helpers.historyAge) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.historyAge); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n    ";
  return buffer;
  }

function program15(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "\n    <dt>Published Date:</dt>\n    <dd>"
    + escapeExpression((helper = helpers.ShortDate || (depth0 && depth0.ShortDate),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.publishedDate), options) : helperMissing.call(depth0, "ShortDate", (depth0 && depth0.publishedDate), options)))
    + " "
    + escapeExpression((helper = helpers.LTS || (depth0 && depth0.LTS),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.publishedDate), options) : helperMissing.call(depth0, "LTS", (depth0 && depth0.publishedDate), options)))
    + "</dd>\n    ";
  return buffer;
  }

function program17(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n<dl class=\"dl-horizontal\">\n\n    <dt>Name:</dt>\n    <dd>";
  if (helper = helpers.sourceTitle) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.sourceTitle); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n\n    ";
  stack1 = helpers['with'].call(depth0, (depth0 && depth0.data), {hash:{},inverse:self.noop,fn:self.program(18, program18, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</dl>\n";
  return buffer;
  }
function program18(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <dt>Message:</dt>\n    <dd>";
  if (helper = helpers.message) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.message); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n    ";
  return buffer;
  }

function program20(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n<dl class=\"dl-horizontal\">\n\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.sourceTitle), {hash:{},inverse:self.noop,fn:self.program(21, program21, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n    ";
  stack1 = helpers['with'].call(depth0, (depth0 && depth0.data), {hash:{},inverse:self.noop,fn:self.program(23, program23, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</dl>\n";
  return buffer;
  }
function program21(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <dt>Name:</dt>\n    <dd>";
  if (helper = helpers.sourceTitle) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.sourceTitle); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n    ";
  return buffer;
  }

function program23(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.droppedPath), {hash:{},inverse:self.noop,fn:self.program(24, program24, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.importedPath), {hash:{},inverse:self.noop,fn:self.program(26, program26, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    ";
  return buffer;
  }
function program24(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <dt>Source:</dt>\n    <dd>";
  if (helper = helpers.droppedPath) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.droppedPath); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n    ";
  return buffer;
  }

function program26(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <dt>Imported To:</dt>\n    <dd>";
  if (helper = helpers.importedPath) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.importedPath); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n    ";
  return buffer;
  }

function program28(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n<dl class=\"dl-horizontal\">\n\n    <dt>Path:</dt>\n    <dd>";
  if (helper = helpers.sourceTitle) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.sourceTitle); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n\n    ";
  stack1 = helpers['with'].call(depth0, (depth0 && depth0.data), {hash:{},inverse:self.noop,fn:self.program(29, program29, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</dl>\n";
  return buffer;
  }
function program29(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n    <dt>Reason:</dt>\n    <dd>\n        ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("Manual")
  },inverse:self.noop,fn:self.program(30, program30, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.reason), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.reason), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n        ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("MissingFromDisk")
  },inverse:self.noop,fn:self.program(32, program32, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.reason), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.reason), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n        ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("Upgrade")
  },inverse:self.noop,fn:self.program(34, program34, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.reason), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.reason), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </dd>\n    ";
  return buffer;
  }
function program30(depth0,data) {
  
  
  return "\n            File was deleted by via UI\n        ";
  }

function program32(depth0,data) {
  
  
  return "\n            Sonarr was unable to find the file on disk so it was removed\n        ";
  }

function program34(depth0,data) {
  
  
  return "\n            File was deleted to import an upgrade\n        ";
  }

  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("grabbed")
  },inverse:self.noop,fn:self.program(1, program1, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.eventType), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.eventType), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("downloadFailed")
  },inverse:self.noop,fn:self.program(17, program17, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.eventType), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.eventType), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("downloadFolderImported")
  },inverse:self.noop,fn:self.program(20, program20, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.eventType), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.eventType), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("episodeFileDeleted")
  },inverse:self.noop,fn:self.program(28, program28, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.eventType), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.eventType), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  return buffer;
  };
this["T"]["series/editor/organize/organizefilesview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n            <li>";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</li>\n            ";
  return buffer;
  }

  buffer += "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        <h3>Organize of Selected Series</h3>\n    </div>\n    <div class=\"modal-body update-files-series-modal\">\n        <div class=\"alert alert-info\">\n            <button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>\n            Tip: To preview a rename... select \"Cancel\" then any series title and use the <i data-original-title=\"\" class=\"icon-nd-rename\" title=\"\"></i>\n        </div>\n\n        Are you sure you want to update all files in the ";
  if (helper = helpers.numberOfSeries) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.numberOfSeries); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " selected series?\n\n        ";
  if (helper = helpers.debug) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.debug); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n        <ul class=\"selected-series\">\n            ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.series), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </ul>\n    </div>\n    <div class=\"modal-footer\">\n        <button class=\"btn\" data-dismiss=\"modal\">cancel</button>\n        <button class=\"btn btn-danger x-confirm-organize\">organize</button>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["series/index/overview/seriesoverviewcollectionview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div id=\"x-series-list\"/>\n";
  };
this["T"]["series/index/overview/seriesoverviewitemview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); partials = this.merge(partials, Handlebars.partials); data = data || {};
  var buffer = "", stack1, helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, functionType="function", self=this;

function program1(depth0,data) {
  
  
  return "\n                        <span class=\"label label-danger\">Ended</span>\n                    ";
  }

function program3(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "\n                        <span class=\"label label-default\">"
    + escapeExpression((helper = helpers.RelativeDate || (depth0 && depth0.RelativeDate),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.nextAiring), options) : helperMissing.call(depth0, "RelativeDate", (depth0 && depth0.nextAiring), options)))
    + "</span>\n                    ";
  return buffer;
  }

  buffer += "<div class=\"series-item\">\n    <div class=\"row\">\n        <div class=\"col-md-2 col-xs-3\">\n            <a href=\"";
  if (helper = helpers.route) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.route); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n                ";
  if (helper = helpers.poster) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.poster); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n            </a>\n        </div>\n        <div class=\"col-md-10 col-xs-9\">\n            <div class=\"row\">\n                <div class=\"col-md-10 col-xs-10\">\n                    <a href=\"";
  if (helper = helpers.route) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.route); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" target=\"_blank\">\n                        <h2>";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h2>\n                    </a>\n                </div>\n                <div class=\"col-md-2 col-xs-2\">\n                    <div class=\"pull-right series-overview-list-actions\">\n                        <i class=\"icon-refresh x-refresh\" title=\"Update series info and scan disk\"/>\n                        <i class=\"icon-nd-edit x-edit\" title=\"Edit Series\"/>\n                    </div>\n                </div>\n            </div>\n            <div class=\"row\">\n                <div class=\"col-md-12 col-xs-12\">\n                    <a href=\"";
  if (helper = helpers.route) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.route); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n                        <div>\n                            ";
  if (helper = helpers.overview) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.overview); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n                        </div>\n                    </a>\n                </div>\n            </div>\n            <div class=\"row\">\n                    <div class=\"col-md-12\">\n                        &nbsp;\n                    </div>\n                </div>\n            <div class=\"row\">\n                <div class=\"col-md-10 col-xs-8\">\n                    ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("ended")
  },inverse:self.noop,fn:self.program(1, program1, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.status), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.status), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n                    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.nextAiring), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n                    ";
  if (helper = helpers.seasonCountHelper) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.seasonCountHelper); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n\n                    "
    + escapeExpression((helper = helpers.profile || (depth0 && depth0.profile),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.profileId), options) : helperMissing.call(depth0, "profile", (depth0 && depth0.profileId), options)))
    + "\n                </div>\n                <div class=\"col-md-2 col-xs-4\">\n                    ";
  stack1 = self.invokePartial(partials.EpisodeProgressPartial, 'EpisodeProgressPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                </div>\n            </div>\n        </div>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["series/index/posters/seriesposterscollectionview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<ul id=\"x-series-posters\" class=\"series-posters\"></ul>";
  };
this["T"]["series/index/posters/seriespostersitemview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); partials = this.merge(partials, Handlebars.partials); data = data || {};
  var buffer = "", stack1, helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, self=this, functionType="function";

function program1(depth0,data) {
  
  
  return "\n                <div class=\"ended-banner\">Ended</div>\n            ";
  }

function program3(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "\n                <span class=\"label label-default\">"
    + escapeExpression((helper = helpers.RelativeDate || (depth0 && depth0.RelativeDate),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.nextAiring), options) : helperMissing.call(depth0, "RelativeDate", (depth0 && depth0.nextAiring), options)))
    + "</span>\n            ";
  return buffer;
  }

  buffer += "<div class=\"series-posters-item\">\n    <div class=\"center\">\n        <div class=\"series-poster-container x-series-poster\">\n            <div class=\"series-controls x-series-controls\">\n                <i class=\"icon-refresh x-refresh\" title=\"Refresh Series\"/>\n                <i class=\"icon-nd-edit x-edit\" title=\"Edit Series\"/>\n            </div>\n            ";
  stack1 = (helper = helpers.unless_eq || (depth0 && depth0.unless_eq),options={hash:{
    'compare': ("continuing")
  },inverse:self.noop,fn:self.program(1, program1, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.status), options) : helperMissing.call(depth0, "unless_eq", (depth0 && depth0.status), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            <a href=\"";
  if (helper = helpers.route) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.route); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n                ";
  if (helper = helpers.poster) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.poster); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n                <div class=\"center title\">";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</div>\n            </a>\n            <div class=\"hidden-title x-title\">\n                ";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n            </div>\n        </div>\n    </div>\n\n    <div class=\"center\">\n        <div class=\"labels\">\n            ";
  stack1 = self.invokePartial(partials.EpisodeProgressPartial, 'EpisodeProgressPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.nextAiring), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </div>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["settings/downloadclient/add/downloadclientaddcollectionview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        <h3>Add Download Client</h3>\n    </div>\n    <div class=\"modal-body\">\n        <div class=\"add-download-client add-thingies\">\n            <ul class=\"items\"></ul>\n        </div>\n    </div>\n    <div class=\"modal-footer\">\n        <button class=\"btn\" data-dismiss=\"modal\">close</button>\n    </div>\n</div>\n";
  };
this["T"]["settings/downloadclient/add/downloadclientadditemview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n        <div class=\"btn-group\">\n            <button class=\"btn btn-xs btn-default dropdown-toggle\" data-toggle=\"dropdown\">\n                Presets\n                <span class=\"caret\"></span>\n            </button>\n            <ul class=\"dropdown-menu\">\n                ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.presets), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            </ul>\n        </div>\n        ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                <li class=\"x-preset\" data-id=\"";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n                    <a>";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</a>\n                </li>\n                ";
  return buffer;
  }

function program4(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n        <a class=\"btn btn-xs btn-default x-info\" href=\"";
  if (helper = helpers.infoLink) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.infoLink); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n            <i class=\"icon-info-sign\"/>\n        </a>\n        ";
  return buffer;
  }

  buffer += "<div class=\"add-thingy\">\n    <div>\n        ";
  if (helper = helpers.implementation) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.implementation); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n    </div>\n    <div class=\"pull-right\">\n        ";
  stack1 = (helper = helpers.if_gt || (depth0 && depth0.if_gt),options={hash:{
    'compare': (0)
  },inverse:self.noop,fn:self.program(1, program1, data),data:data},helper ? helper.call(depth0, ((stack1 = (depth0 && depth0.presets)),stack1 == null || stack1 === false ? stack1 : stack1.length), options) : helperMissing.call(depth0, "if_gt", ((stack1 = (depth0 && depth0.presets)),stack1 == null || stack1 === false ? stack1 : stack1.length), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.infoLink), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n</div>";
  return buffer;
  };
this["T"]["settings/downloadclient/delete/downloadclientdeleteview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        <h3>Delete Download Client</h3>\n    </div>\n    <div class=\"modal-body\">\n        <p>Are you sure you want to delete '";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "'?</p>\n    </div>\n    <div class=\"modal-footer\">\n        <button class=\"btn\" data-dismiss=\"modal\">cancel</button>\n        <button class=\"btn btn-danger x-confirm-delete\">delete</button>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["settings/downloadclient/downloadhandling/downloadhandlingview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<fieldset>\n    <legend>Completed Download Handling</legend>\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Enable</label>\n\n        <div class=\"col-sm-8\">\n            <div class=\"input-group\">\n                <label class=\"checkbox toggle well\">\n                    <input type=\"checkbox\" name=\"enableCompletedDownloadHandling\" class=\"x-completed-download-handling\"/>\n                    <p>\n                        <span>Yes</span>\n                        <span>No</span>\n                    </p>\n\n                    <div class=\"btn btn-primary slide-button\"/>\n                </label>\n                <span class=\"help-inline-checkbox\">\n                    <i class=\"icon-nd-form-info\" title=\"Automatically import completed downloads from download client\"/>\n                </span>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"x-completed-download-options advanced-setting\">\n        <div class=\"form-group\">\n            <label class=\"col-sm-3 control-label\">Remove</label>\n\n            <div class=\"col-sm-8\">\n                <div class=\"input-group\">\n                    <label class=\"checkbox toggle well\">\n                        <input type=\"checkbox\" name=\"removeCompletedDownloads\"/>\n                        <p>\n                            <span>Yes</span>\n                            <span>No</span>\n                        </p>\n\n                        <div class=\"btn btn-primary slide-button\"/>\n                    </label>\n\n                    <span class=\"help-inline-checkbox\">\n                        <i class=\"icon-nd-form-info\" title=\"Remove imported downloads from download client history\"/>\n                    </span>\n                </div>\n            </div>\n        </div>\n    </div>\n</fieldset>\n\n<fieldset>\n    <legend>Failed Download Handling</legend>\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Redownload</label>\n\n        <div class=\"col-sm-8\">\n            <div class=\"input-group\">\n                <label class=\"checkbox toggle well\">\n                    <input type=\"checkbox\" name=\"autoRedownloadFailed\" class=\"x-failed-auto-redownload\"/>\n                    <p>\n                        <span>Yes</span>\n                        <span>No</span>\n                    </p>\n\n                    <div class=\"btn btn-primary slide-button\"/>\n                </label>\n\n                    <span class=\"help-inline-checkbox\">\n                    <i class=\"icon-nd-form-info\" title=\"Automatically search for and attempt to download a different release\"/>\n                    </span>\n            </div>\n        </div>\n    </div>\n    <div class=\"x-failed-download-options advanced-setting\">\n        <div class=\"form-group \">\n            <label class=\"col-sm-3 control-label\">Remove</label>\n            <div class=\"col-sm-8\">\n                <div class=\"input-group\">\n                    <label class=\"checkbox toggle well\">\n                        <input type=\"checkbox\" name=\"removeFailedDownloads\"/>\n                        <p>\n                            <span>Yes</span>\n                            <span>No</span>\n                        </p>\n\n                        <div class=\"btn btn-primary slide-button\"/>\n                    </label>\n                    <span class=\"help-inline-checkbox\">\n                    <i class=\"icon-nd-form-info\" title=\"Remove failed downloads from download client history\"/>\n                    </span>\n                </div>\n            </div>\n        </div>\n    </div>\n</fieldset>";
  };
this["T"]["settings/downloadclient/dronefactory/dronefactoryview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<fieldset class=\"advanced-setting\">\n    <legend>Drone Factory Options</legend>\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Drone Factory</label>\n\n        <div class=\"col-sm-1 col-sm-push-8 help-inline\">\n            <i class=\"icon-nd-form-info\" title=\"Optional folder to periodically scan for possible imports\"/>\n            <i class=\"icon-nd-form-warning\" title=\"Do not use the folder that contains some or all of your sorted and named TV shows - doing so could cause data loss\"></i>\n            <i class=\"icon-nd-form-warning\" title=\"Download client history items that are stored in the drone factory will be ignored.\"/>\n        </div>\n\n        <div class=\"col-sm-8 col-sm-pull-1\">\n            <input type=\"text\" name=\"downloadedEpisodesFolder\" class=\"form-control x-path\" />\n        </div>\n    </div>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Drone Factory Interval</label>\n\n        <div class=\"col-sm-1 col-sm-push-2 help-inline\">\n            <i class=\"icon-nd-form-info\" title=\"Interval in minutes to scan the Drone Factory. Set to zero to disable.\"/>\n            <i class=\"icon-nd-form-warning\" title=\"Setting a high interval or disabling scanning will prevent episodes from being imported.\"></i>\n        </div>\n\n        <div class=\"col-sm-2 col-sm-pull-1\">\n            <input type=\"number\" name=\"downloadedEpisodesScanInterval\" class=\"form-control\" />\n        </div>\n    </div>\n</fieldset>";
  };
this["T"]["settings/downloadclient/edit/downloadclienteditview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n            <h3>Edit - ";
  if (helper = helpers.implementation) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.implementation); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h3>\n        ";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n            <h3>Add - ";
  if (helper = helpers.implementation) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.implementation); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h3>\n        ";
  return buffer;
  }

function program5(depth0,data) {
  
  
  return "\n            <button class=\"btn btn-danger pull-left x-delete\">delete</button>\n        ";
  }

function program7(depth0,data) {
  
  
  return "\n            <button class=\"btn pull-left x-back\">back</button>\n        ";
  }

  buffer += "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.id), {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n    <div class=\"modal-body download-client-modal\">\n        <div class=\"form-horizontal\">\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Name</label>\n\n                <div class=\"col-sm-5\">\n                    <input type=\"text\" name=\"name\" class=\"form-control\"/>\n                </div>\n            </div>\n\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Enable</label>\n\n                <div class=\"col-sm-5\">\n                    <div class=\"input-group\">\n                        <label class=\"checkbox toggle well\">\n                            <input type=\"checkbox\" name=\"enable\"/>\n                            <p>\n                                <span>Yes</span>\n                                <span>No</span>\n                            </p>\n\n                            <div class=\"btn btn-primary slide-button\"/>\n                        </label>\n                    </div>\n                </div>\n            </div>\n\n            ";
  if (helper = helpers.formBuilder) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.formBuilder); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n        </div>\n    </div>\n    <div class=\"modal-footer\">\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.id), {hash:{},inverse:self.program(7, program7, data),fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n        <span class=\"indicator x-indicator\"><i class=\"icon-spinner icon-spin\"></i></span>\n        <button class=\"btn x-test\">test <i class=\"x-test-icon icon-nd-test\"/></button>\n        <button class=\"btn\" data-dismiss=\"modal\">cancel</button>\n\n        <div class=\"btn-group\">\n            <button class=\"btn btn-primary x-save\">save</button>\n            <button class=\"btn btn-icon-only btn-primary dropdown-toggle\" data-toggle=\"dropdown\">\n                <span class=\"caret\"></span>\n            </button>\n            <ul class=\"dropdown-menu\">\n                <li class=\"save-and-add x-save-and-add\">\n                    save and add\n                </li>\n            </ul>\n        </div>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["settings/downloadclient/remotepathmapping/remotepathmappingcollectionview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<fieldset class=\"advanced-setting\">\n    <legend>Remote Path Mappings</legend>\n\n    <div class=\"col-md-12\">\n        <div class=\"rule-setting-list\">\n            <div class=\"rule-setting-header x-header hidden-xs\">\n                <div class=\"row\">\n                    <span class=\"col-sm-2\">Host</span>\n                    <span class=\"col-sm-5\">Remote Path</span>\n                    <span class=\"col-sm-4\">Local Path</span>\n                </div>\n            </div>\n            <div class=\"rows x-rows\">\n            </div>\n            <div class=\"rule-setting-footer\">\n                <div class=\"pull-right\">\n                    <span class=\"add-rule-setting-mapping\">\n                        <i class=\"icon-nd-add x-add\" title=\"Add new mapping\" />\n                    </span>\n                </div>\n            </div>\n        </div>\n    </div>\n</fieldset>";
  };
this["T"]["settings/downloadclient/remotepathmapping/remotepathmappingdeleteview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        <h3>Delete Mapping</h3>\n    </div>\n    <div class=\"modal-body\">\n        <p>Are you sure you want to delete the mapping for '";
  if (helper = helpers.localPath) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.localPath); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "'?</p>\n    </div>\n    <div class=\"modal-footer\">\n        <button class=\"btn\" data-dismiss=\"modal\">cancel</button>\n        <button class=\"btn btn-danger x-confirm-delete\">delete</button>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["settings/downloadclient/remotepathmapping/remotepathmappingeditview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, self=this;

function program1(depth0,data) {
  
  
  return "\n            <h3>Edit Mapping</h3>\n        ";
  }

function program3(depth0,data) {
  
  
  return "\n            <h3>Add Mapping</h3>\n        ";
  }

function program5(depth0,data) {
  
  
  return "\n            <button class=\"btn btn-danger pull-left x-delete\">delete</button>\n        ";
  }

  buffer += "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.id), {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n    <div class=\"modal-body remotepath-mapping-modal\">\n        <div class=\"form-horizontal\">\n            <div>\n                <p>Use this feature if you have a remotely running Download Client. Sonarr will use the information provided to translate the paths provided by the Download Client API to something Sonarr can access and import.</p>\n            </div>\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Host</label>\n\n                <div class=\"col-sm-1 col-sm-push-3 help-inline\">\n                    <i class=\"icon-nd-form-info\" title=\"Host you specified for the remote Download Client.\" />\n                </div>\n\n                <div class=\"col-sm-3 col-sm-pull-1\">\n                    <input type=\"text\" name=\"host\" class=\"form-control\"/>\n                </div>\n            </div>\n\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Remote Path</label>\n\n                <div class=\"col-sm-1 col-sm-push-5 help-inline\">\n                    <i class=\"icon-nd-form-info\" title=\"Root path to the directory that the Download Client accesses.\" />\n                </div>\n\n                <div class=\"col-sm-5 col-sm-pull-1\">\n                    <input type=\"text\" name=\"remotePath\" class=\"form-control\"/>\n                </div>\n            </div>\n\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Local Path</label>\n\n                <div class=\"col-sm-1 col-sm-push-5 help-inline\">\n                    <i class=\"icon-nd-form-info\" title=\"Path that Sonarr should use to access the same directory remotely.\" />\n                </div>\n\n                <div class=\"col-sm-5 col-sm-pull-1\">\n                    <input type=\"text\" name=\"localPath\" class=\"form-control x-path\"/>\n                </div>\n            </div>\n        </div>\n    </div>\n    <div class=\"modal-footer\">\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.id), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n        <button class=\"btn\" data-dismiss=\"modal\">cancel</button>\n\n        <div class=\"btn-group\">\n            <button class=\"btn btn-primary x-save\">save</button>\n        </div>\n    </div>\n</div>";
  return buffer;
  };
this["T"]["settings/downloadclient/remotepathmapping/remotepathmappingitemview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "    <div class=\"col-sm-2\">\n        ";
  if (helper = helpers.host) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.host); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n    </div>\n    <div class=\"col-sm-5\">\n        ";
  if (helper = helpers.remotePath) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.remotePath); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n    </div>\n    <div class=\"col-sm-4\">\n        ";
  if (helper = helpers.localPath) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.localPath); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n    </div>\n    <div class=\"col-sm-1\">\n        <div class=\"pull-right\"><i class=\"icon-nd-edit x-edit\" title=\"\" data-original-title=\"Edit Mapping\"></i></div>\n    </div>";
  return buffer;
  };
this["T"]["settings/indexers/add/indexeraddcollectionview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        <h3>Add Indexer</h3>\n    </div>\n    <div class=\"modal-body\">\n        <div class=\"add-indexer add-thingies\">\n            <ul class=\"items\"></ul>\n        </div>\n    </div>\n    <div class=\"modal-footer\">\n        <button class=\"btn\" data-dismiss=\"modal\">close</button>\n    </div>\n</div>\n";
  };
this["T"]["settings/indexers/add/indexeradditemview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n        <div class=\"btn-group\">\n            <button class=\"btn btn-xs btn-default dropdown-toggle\" data-toggle=\"dropdown\">\n                Presets\n                <span class=\"caret\"></span>\n            </button>\n            <ul class=\"dropdown-menu\">\n                ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.presets), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            </ul>\n        </div>\n        ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                <li class=\"x-preset\" data-id=\"";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n                    <a>";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</a>\n                </li>\n                ";
  return buffer;
  }

function program4(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n        <a class=\"btn btn-xs btn-default x-info\" href=\"";
  if (helper = helpers.infoLink) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.infoLink); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n            <i class=\"icon-info-sign\"/>\n        </a>\n        ";
  return buffer;
  }

  buffer += "<div class=\"add-thingy\">\n    <div>\n        ";
  if (helper = helpers.implementation) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.implementation); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n    </div>\n    <div class=\"pull-right\">\n        ";
  stack1 = (helper = helpers.if_gt || (depth0 && depth0.if_gt),options={hash:{
    'compare': (0)
  },inverse:self.noop,fn:self.program(1, program1, data),data:data},helper ? helper.call(depth0, ((stack1 = (depth0 && depth0.presets)),stack1 == null || stack1 === false ? stack1 : stack1.length), options) : helperMissing.call(depth0, "if_gt", ((stack1 = (depth0 && depth0.presets)),stack1 == null || stack1 === false ? stack1 : stack1.length), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.infoLink), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n</div>";
  return buffer;
  };
this["T"]["settings/indexers/delete/indexerdeleteview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        <h3>Delete Indexer</h3>\n    </div>\n    <div class=\"modal-body\">\n        <p>Are you sure you want to delete '";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "'?</p>\n    </div>\n    <div class=\"modal-footer\">\n        <button class=\"btn\" data-dismiss=\"modal\">cancel</button>\n        <button class=\"btn btn-danger x-confirm-delete\">delete</button>\n    </div>\n</div>";
  return buffer;
  };
this["T"]["settings/indexers/edit/indexereditview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n            <h3>Edit - ";
  if (helper = helpers.implementation) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.implementation); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h3>\n        ";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n            <h3>Add - ";
  if (helper = helpers.implementation) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.implementation); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h3>\n        ";
  return buffer;
  }

function program5(depth0,data) {
  
  
  return "disabled=\"disabled\"";
  }

function program7(depth0,data) {
  
  
  return "\n                        <span class=\"help-inline-checkbox\">\n                            <i class=\"icon-nd-form-warning\" title=\"\" data-original-title=\"RSS is not supported with this indexer\"></i>\n                        </span>\n                        ";
  }

function program9(depth0,data) {
  
  
  return "\n                        <span class=\"help-inline-checkbox\">\n                            <i class=\"icon-nd-form-warning\" title=\"\" data-original-title=\"Search is not supported with this indexer\"></i>\n                        </span>\n                        ";
  }

function program11(depth0,data) {
  
  
  return "\n            <button class=\"btn btn-danger pull-left x-delete\">delete</button>\n        ";
  }

function program13(depth0,data) {
  
  
  return "\n            <button class=\"btn pull-left x-back\">back</button>\n        ";
  }

  buffer += "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" aria-hidden=\"true\" data-dismiss=\"modal\">&times;</button>\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.id), {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n    <div class=\"modal-body indexer-modal\">\n        <div class=\"form-horizontal\">\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Name</label>\n\n                <div class=\"col-sm-5\">\n                    <input type=\"text\" name=\"name\" class=\"form-control\"/>\n                </div>\n            </div>\n\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Enable RSS Sync</label>\n\n                <div class=\"col-sm-5\">\n                    <div class=\"input-group\">\n                        <label class=\"checkbox toggle well\">\n                            <input type=\"checkbox\" name=\"enableRss\" ";
  stack1 = helpers.unless.call(depth0, (depth0 && depth0.supportsRss), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "/>\n                            <p>\n                                <span>Yes</span>\n                                <span>No</span>\n                            </p>\n\n                            <div class=\"btn btn-primary slide-button\"/>\n                        </label>\n                        ";
  stack1 = helpers.unless.call(depth0, (depth0 && depth0.supportsRss), {hash:{},inverse:self.noop,fn:self.program(7, program7, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                    </div>\n                </div>\n            </div>\n\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Enable Search</label>\n\n                <div class=\"col-sm-5\">\n                    <div class=\"input-group\">\n                        <label class=\"checkbox toggle well\">\n\n                            <input type=\"checkbox\" name=\"enableSearch\" ";
  stack1 = helpers.unless.call(depth0, (depth0 && depth0.supportsSearch), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "/>\n                            <p>\n                                <span>Yes</span>\n                                <span>No</span>\n                            </p>\n\n                            <div class=\"btn btn-primary slide-button\"/>\n                        </label>\n                        ";
  stack1 = helpers.unless.call(depth0, (depth0 && depth0.supportsSearch), {hash:{},inverse:self.noop,fn:self.program(9, program9, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                    </div>\n                </div>\n            </div>\n\n            ";
  if (helper = helpers.formBuilder) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.formBuilder); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n        </div>\n    </div>\n    <div class=\"modal-footer\">\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.id), {hash:{},inverse:self.program(13, program13, data),fn:self.program(11, program11, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        <span class=\"indicator x-indicator\"><i class=\"icon-spinner icon-spin\"></i></span>\n        <button class=\"btn x-test\">test <i class=\"x-test-icon icon-nd-test\"/></button>\n        <button class=\"btn\" data-dismiss=\"modal\">cancel</button>\n\n        <div class=\"btn-group\">\n            <button class=\"btn btn-primary x-save\">save</button>\n            <button class=\"btn btn-icon-only btn-primary dropdown-toggle\" data-toggle=\"dropdown\">\n                <span class=\"caret\"></span>\n            </button>\n            <ul class=\"dropdown-menu\">\n                <li class=\"save-and-add x-save-and-add\">\n                    save and add\n                </li>\n            </ul>\n        </div>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["settings/indexers/options/indexeroptionsview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<fieldset>\n    <legend>Options</legend>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Minimum Age</label>\n\n        <div class=\"col-sm-1 col-sm-push-2 help-inline\">\n            <i class=\"icon-nd-form-info\" title=\"Usenet only: Minimum age in minutes of NZBs before they are grabbed. Use this to give new releases time to propagate to your usenet provider.\"/>\n        </div>\n\n        <div class=\"col-sm-2 col-sm-pull-1\">\n            <input type=\"number\" min=\"0\" name=\"minimumAge\" class=\"form-control\"/>\n        </div>\n    </div>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Retention</label>\n\n        <div class=\"col-sm-1 col-sm-push-2 help-inline\">\n            <i class=\"icon-nd-form-info\" title=\"Usenet only: Set to zero to set to unlimited\"/>\n        </div>\n\n        <div class=\"col-sm-2 col-sm-pull-1\">\n            <input type=\"number\" min=\"0\" name=\"retention\" class=\"form-control\"/>\n        </div>\n    </div>\n\n    <div class=\"form-group advanced-setting\">\n        <label class=\"col-sm-3 control-label\">RSS Sync Interval</label>\n\n        <div class=\"col-sm-1 col-sm-push-2 help-inline\">\n            <i class=\"icon-nd-form-warning\" title=\"This will apply to all indexers, please follow the rules set forth by them\"/>\n            <i class=\"icon-nd-form-info\" title=\"Set to zero to disable (this will stop all automatic release grabbing)\"/>\n        </div>\n\n        <div class=\"col-sm-2 col-sm-pull-1\">\n            <input type=\"number\" name=\"rssSyncInterval\" class=\"form-control\"/>\n        </div>\n    </div>\n</fieldset>\n";
  };
this["T"]["settings/indexers/restriction/restrictioncollectionview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<fieldset class=\"advanced-setting\">\n    <legend>Restrictions</legend>\n\n    <div class=\"col-md-12\">\n        <div class=\"rule-setting-list\">\n            <div class=\"rule-setting-header x-header hidden-xs\">\n                <div class=\"row\">\n                    <span class=\"col-sm-4\">Must Contain</span>\n                    <span class=\"col-sm-4\">Must Not Contain</span>\n                    <span class=\"col-sm-3\">Tags</span>\n                </div>\n            </div>\n            <div class=\"rows x-rows\">\n            </div>\n            <div class=\"rule-setting-footer\">\n                <div class=\"pull-right\">\n                    <span class=\"add-rule-setting-mapping\">\n                        <i class=\"icon-nd-add x-add\" title=\"Add new restriction\" />\n                    </span>\n                </div>\n            </div>\n        </div>\n    </div>\n</fieldset>";
  };
this["T"]["settings/indexers/restriction/restrictiondeleteview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        <h3>Delete Restriction</h3>\n    </div>\n    <div class=\"modal-body\">\n        <p>Are you sure you want to delete the restriction for '";
  if (helper = helpers.localPath) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.localPath); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "'?</p>\n    </div>\n    <div class=\"modal-footer\">\n        <button class=\"btn\" data-dismiss=\"modal\">cancel</button>\n        <button class=\"btn btn-danger x-confirm-delete\">delete</button>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["settings/indexers/restriction/restrictioneditview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, self=this;

function program1(depth0,data) {
  
  
  return "\n            <h3>Edit Restriction</h3>\n        ";
  }

function program3(depth0,data) {
  
  
  return "\n            <h3>Add Restriction</h3>\n        ";
  }

function program5(depth0,data) {
  
  
  return "\n            <button class=\"btn btn-danger pull-left x-delete\">delete</button>\n        ";
  }

  buffer += "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.id), {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n    <div class=\"modal-body remotepath-mapping-modal\">\n        <div class=\"form-horizontal\">\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Must contain</label>\n\n                <div class=\"col-sm-1 col-sm-push-5 help-inline\">\n                    <i class=\"icon-nd-form-info\" title=\"The release must contain at least one of these terms (case insensitive)\" />\n                </div>\n\n                <div class=\"col-sm-5 col-sm-pull-1\">\n                    <input type=\"text\" name=\"required\" class=\"form-control x-required\"/>\n                </div>\n            </div>\n\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Must not contain</label>\n\n                <div class=\"col-sm-1 col-sm-push-5 help-inline\">\n                    <i class=\"icon-nd-form-info\" title=\"The release will be rejected if it contains one or more of terms (case insensitive)\" />\n                </div>\n\n                <div class=\"col-sm-5 col-sm-pull-1\">\n                    <input type=\"text\" name=\"ignored\" class=\"form-control x-ignored\"/>\n                </div>\n            </div>\n\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Tags</label>\n\n                <div class=\"col-sm-1 col-sm-push-5 help-inline\">\n                    <i class=\"icon-nd-form-info\" title=\"Restrictions will apply to series with more or more matching tags. Leave blank to apply to all series\" />\n                </div>\n\n                <div class=\"col-sm-5 col-sm-pull-1\">\n                    <input type=\"text\" class=\"form-control x-tags\">\n                </div>\n            </div>\n        </div>\n    </div>\n    <div class=\"modal-footer\">\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.id), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n        <button class=\"btn\" data-dismiss=\"modal\">cancel</button>\n\n        <div class=\"btn-group\">\n            <button class=\"btn btn-primary x-save\">save</button>\n        </div>\n    </div>\n</div>";
  return buffer;
  };
this["T"]["settings/indexers/restriction/restrictionitemview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression;


  buffer += "    <div class=\"col-sm-4\">\n        "
    + escapeExpression((helper = helpers.genericTagDisplay || (depth0 && depth0.genericTagDisplay),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.required), "label label-success", options) : helperMissing.call(depth0, "genericTagDisplay", (depth0 && depth0.required), "label label-success", options)))
    + "\n    </div>\n    <div class=\"col-sm-4\">\n        "
    + escapeExpression((helper = helpers.genericTagDisplay || (depth0 && depth0.genericTagDisplay),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.ignored), "label label-danger", options) : helperMissing.call(depth0, "genericTagDisplay", (depth0 && depth0.ignored), "label label-danger", options)))
    + "\n    </div>\n    <div class=\"col-sm-3\">\n        "
    + escapeExpression((helper = helpers.tagDisplay || (depth0 && depth0.tagDisplay),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.tags), options) : helperMissing.call(depth0, "tagDisplay", (depth0 && depth0.tags), options)))
    + "\n    </div>\n    <div class=\"col-sm-1\">\n        <div class=\"pull-right\"><i class=\"icon-nd-edit x-edit\" title=\"\" data-original-title=\"Edit\"></i></div>\n    </div>";
  return buffer;
  };
this["T"]["settings/mediamanagement/filemanagement/filemanagementview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<fieldset>\n    <legend>File Management</legend>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Ignore Deleted Episodes</label>\n\n        <div class=\"col-sm-9\">\n            <div class=\"input-group\">\n                <label class=\"checkbox toggle well\">\n                    <input type=\"checkbox\" name=\"autoUnmonitorPreviouslyDownloadedEpisodes\"/>\n                    <p>\n                        <span>Yes</span>\n                        <span>No</span>\n                    </p>\n\n                    <div class=\"btn btn-primary slide-button\"/>\n                </label>\n\n                <span class=\"help-inline-checkbox\">\n                    <i class=\"icon-nd-form-info\" title=\"Episodes deleted from disk are automatically unmonitored in Sonarr\"/>\n                </span>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"form-group advanced-setting\">\n        <label class=\"col-sm-3 control-label\">Download Propers</label>\n\n        <div class=\"col-sm-9\">\n            <div class=\"input-group\">\n                <label class=\"checkbox toggle well\">\n                    <input type=\"checkbox\" name=\"autoDownloadPropers\"/>\n                    <p>\n                        <span>Yes</span>\n                        <span>No</span>\n                    </p>\n\n                    <div class=\"btn btn-primary slide-button\"/>\n                </label>\n\n                <span class=\"help-inline-checkbox\">\n                    <i class=\"icon-nd-form-info\" title=\"Should Sonarr automatically upgrade to propers when available?\"/>\n                </span>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"form-group advanced-setting\">\n        <label class=\"col-sm-3 control-label\">Analyse video files</label>\n\n        <div class=\"col-sm-9\">\n            <div class=\"input-group\">\n                <label class=\"checkbox toggle well\">\n                    <input type=\"checkbox\" name=\"enableMediaInfo\"/>\n                    <p>\n                        <span>Yes</span>\n                        <span>No</span>\n                    </p>\n\n                    <div class=\"btn btn-primary slide-button\"/>\n                </label>\n\n                <span class=\"help-inline-checkbox\">\n                    <i class=\"icon-nd-form-info\" title=\"Extract video information such as resolution, runtime and codec information from files. This requires Sonnar to read parts of the file which may cause high disk or network activity during scans.\"/>\n                </span>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"form-group advanced-setting\">\n        <label class=\"col-sm-3 control-label\">Change File Date</label>\n\n        <div class=\"col-sm-1 col-sm-push-2 help-inline\">\n            <i class=\"icon-nd-form-info\" title=\"Change file date on import/rescan\"/>\n        </div>\n        \n        <div class=\"col-sm-2 col-sm-pull-1\">\n            <select class=\"form-control\" name=\"fileDate\">\n                <option value=\"none\">None</option>\n                <option value=\"localAirDate\">Local Air Date</option>\n                <option value=\"utcAirDate\">UTC Air Date</option>\n            </select>\n        </div>\n    </div>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Recycling Bin</label>\n\n        <div class=\"col-sm-1 col-sm-push-8 help-inline\">\n            <i class=\"icon-nd-form-info\" title=\"Episode files will go here when deleted instead of being permanently deleted\"/>\n        </div>\n\n        <div class=\"col-sm-8 col-sm-pull-1\">\n            <input type=\"text\" name=\"recycleBin\" class=\"form-control x-path\"/>\n        </div>\n\n    </div>\n</fieldset>\n";
  };
this["T"]["settings/mediamanagement/naming/namingview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); partials = this.merge(partials, Handlebars.partials); data = data || {};
  var buffer = "", stack1, self=this;


  buffer += "<fieldset>\n    <legend>Episode Naming</legend>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Rename Episodes</label>\n\n        <div class=\"col-sm-8\">\n            <div class=\"input-group\">\n                <label class=\"checkbox toggle well\">\n                    <input type=\"checkbox\" name=\"renameEpisodes\" class=\"x-rename-episodes\"/>\n\n                    <p>\n                        <span>Yes</span>\n                        <span>No</span>\n                    </p>\n\n                    <div class=\"btn btn-primary slide-button\"/>\n                </label>\n\n                <span class=\"help-inline-checkbox\">\n                    <i class=\"icon-nd-form-warning\" title=\"Sonarr will use the existing file name if set to no\"/>\n                </span>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"x-naming-options\">\n        <div class=\"basic-setting x-basic-naming\"></div>\n\n        <div class=\"form-group advanced-setting\">\n            <label class=\"col-sm-3 control-label\">Standard Episode Format</label>\n\n            <div class=\"col-sm-1 col-sm-push-8 help-inline\">\n                <i class=\"icon-nd-form-info\" title=\"\" data-original-title=\"All caps or all lower-case can also be used\"></i>\n                <a href=\"https://github.com/NzbDrone/NzbDrone/wiki/Sorting-and-Renaming\" class=\"help-link\" title=\"More information\"><i class=\"icon-nd-form-info-link\"/></a>\n            </div>\n\n            <div class=\"col-sm-8 col-sm-pull-1\">\n                <div class=\"input-group x-helper-input\">\n                    <input type=\"text\" class=\"form-control naming-format\" name=\"standardEpisodeFormat\" data-onkeyup=\"true\" />\n                    <div class=\"input-group-btn btn-group x-naming-token-helper\">\n                        <button class=\"btn btn-icon-only dropdown-toggle\" data-toggle=\"dropdown\">\n                            <i class=\"icon-plus\"></i>\n                        </button>\n                        <ul class=\"dropdown-menu\">\n                            ";
  stack1 = self.invokePartial(partials.SeriesTitleNamingPartial, 'SeriesTitleNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.SeasonNamingPartial, 'SeasonNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.EpisodeNamingPartial, 'EpisodeNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.EpisodeTitleNamingPartial, 'EpisodeTitleNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.QualityNamingPartial, 'QualityNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.MediaInfoNamingPartial, 'MediaInfoNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.ReleaseGroupNamingPartial, 'ReleaseGroupNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.OriginalTitleNamingPartial, 'OriginalTitleNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.SeparatorNamingPartial, 'SeparatorNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                        </ul>\n                    </div>\n                </div>\n            </div>\n        </div>\n\n        <div class=\"form-group advanced-setting\">\n            <label class=\"col-sm-3 control-label\">Daily Episode Format</label>\n\n            <div class=\"col-sm-1 col-sm-push-8 help-inline\">\n                <i class=\"icon-nd-form-info\" title=\"\" data-original-title=\"All caps or all lower-case can also be used\"></i>\n                <a href=\"https://github.com/NzbDrone/NzbDrone/wiki/Sorting-and-Renaming\" class=\"help-link\" title=\"More information\"><i class=\"icon-nd-form-info-link\"/></a>\n            </div>\n\n            <div class=\"col-sm-8 col-sm-pull-1\">\n                <div class=\"input-group x-helper-input\">\n                    <input type=\"text\" class=\"form-control naming-format\" name=\"dailyEpisodeFormat\" data-onkeyup=\"true\" />\n                    <div class=\"input-group-btn btn-group x-naming-token-helper\">\n                        <button class=\"btn btn-icon-only dropdown-toggle\" data-toggle=\"dropdown\">\n                            <i class=\"icon-plus\"></i>\n                        </button>\n                        <ul class=\"dropdown-menu\">\n                            ";
  stack1 = self.invokePartial(partials.SeriesTitleNamingPartial, 'SeriesTitleNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.AirDateNamingPartial, 'AirDateNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.SeasonNamingPartial, 'SeasonNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.EpisodeNamingPartial, 'EpisodeNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.EpisodeTitleNamingPartial, 'EpisodeTitleNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.QualityNamingPartial, 'QualityNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.MediaInfoNamingPartial, 'MediaInfoNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.ReleaseGroupNamingPartial, 'ReleaseGroupNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.OriginalTitleNamingPartial, 'OriginalTitleNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.SeparatorNamingPartial, 'SeparatorNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                        </ul>\n                    </div>\n                </div>\n            </div>\n        </div>\n\n        <div class=\"form-group advanced-setting\">\n            <label class=\"col-sm-3 control-label\">Anime Episode Format</label>\n\n            <div class=\"col-sm-1 col-sm-push-8 help-inline\">\n                <i class=\"icon-nd-form-info\" title=\"\" data-original-title=\"All caps or all lower-case can also be used\"></i>\n                <a href=\"https://github.com/NzbDrone/NzbDrone/wiki/Sorting-and-Renaming\" class=\"help-link\" title=\"More information\"><i class=\"icon-nd-form-info-link\"/></a>\n            </div>\n\n            <div class=\"col-sm-8 col-sm-pull-1\">\n                <div class=\"input-group x-helper-input\">\n                    <input type=\"text\" class=\"form-control naming-format\" name=\"animeEpisodeFormat\" data-onkeyup=\"true\" />\n                    <div class=\"input-group-btn btn-group x-naming-token-helper\">\n                        <button class=\"btn btn-icon-only dropdown-toggle\" data-toggle=\"dropdown\">\n                            <i class=\"icon-plus\"></i>\n                        </button>\n                        <ul class=\"dropdown-menu\">\n                            ";
  stack1 = self.invokePartial(partials.SeriesTitleNamingPartial, 'SeriesTitleNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.AbsoluteEpisodeNamingPartial, 'AbsoluteEpisodeNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.SeasonNamingPartial, 'SeasonNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.EpisodeNamingPartial, 'EpisodeNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.EpisodeTitleNamingPartial, 'EpisodeTitleNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.QualityNamingPartial, 'QualityNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.MediaInfoNamingPartial, 'MediaInfoNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.ReleaseGroupNamingPartial, 'ReleaseGroupNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.OriginalTitleNamingPartial, 'OriginalTitleNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                            ";
  stack1 = self.invokePartial(partials.SeparatorNamingPartial, 'SeparatorNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                        </ul>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"form-group advanced-setting\">\n        <label class=\"col-sm-3 control-label\">Series Folder Format</label>\n\n        <div class=\"col-sm-1 col-sm-push-8 help-inline\">\n            <i class=\"icon-nd-form-info\" title=\"\" data-original-title=\"All caps or all lower-case can also be used. Only used when adding a new series.\"></i>\n        </div>\n\n        <div class=\"col-sm-8 col-sm-pull-1\">\n            <div class=\"input-group x-helper-input\">\n                <input type=\"text\" class=\"form-control naming-format\" name=\"seriesFolderFormat\" data-onkeyup=\"true\"/>\n                <div class=\"input-group-btn btn-group x-naming-token-helper\">\n                    <button class=\"btn btn-icon-only dropdown-toggle\" data-toggle=\"dropdown\">\n                        <i class=\"icon-plus\"></i>\n                    </button>\n                    <ul class=\"dropdown-menu\">\n                        ";
  stack1 = self.invokePartial(partials.SeriesTitleNamingPartial, 'SeriesTitleNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                    </ul>\n                </div>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Season Folder Format</label>\n\n        <div class=\"col-sm-8\">\n            <div class=\"input-group x-helper-input\">\n                <input type=\"text\" class=\"form-control naming-format\" name=\"seasonFolderFormat\" data-onkeyup=\"true\"/>\n                <div class=\"input-group-btn btn-group x-naming-token-helper\">\n                    <button class=\"btn btn-icon-only dropdown-toggle\" data-toggle=\"dropdown\">\n                        <i class=\"icon-plus\"></i>\n                    </button>\n                    <ul class=\"dropdown-menu\">\n                        ";
  stack1 = self.invokePartial(partials.SeriesTitleNamingPartial, 'SeriesTitleNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                        ";
  stack1 = self.invokePartial(partials.SeasonNamingPartial, 'SeasonNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                        ";
  stack1 = self.invokePartial(partials.SeparatorNamingPartial, 'SeparatorNamingPartial', depth0, helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                    </ul>\n                </div>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"x-naming-options\">\n        <div class=\"form-group\">\n            <label class=\"col-sm-3 control-label\">Multi-Episode Style</label>\n\n            <div class=\"col-sm-2\">\n                <select class=\"form-control x-multi-episode-style\" name=\"multiEpisodeStyle\">\n                    <option value=\"0\">Extend</option>\n                    <option value=\"1\">Duplicate</option>\n                    <option value=\"2\">Repeat</option>\n                    <option value=\"3\">Scene</option>\n                    <option value=\"4\">Range</option>\n                    <option value=\"5\">Prefixed Range</option>\n                </select>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Single Episode Example</label>\n        \n        <div class=\"col-sm-8\">\n            <p class=\"form-control-static x-single-episode-example naming-example\"></p>\n        </div>\n    </div>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Multi-Episode Example</label>\n\n        <div class=\"col-sm-8\">\n            <p class=\"form-control-static x-multi-episode-example naming-example\"></p>\n        </div>\n    </div>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Daily-Episode Example</label>\n\n        <div class=\"col-sm-8\">\n            <p class=\"form-control-static x-daily-episode-example naming-example\"></p>\n        </div>\n    </div>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Anime Episode Example</label>\n        <div class=\"col-sm-8\">\n            <p class=\"form-control-static x-anime-episode-example naming-example\"></p>\n        </div>\n    </div>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Anime Multi-Episode Example</label>\n\n        <div class=\"col-sm-8\">\n            <p class=\"form-control-static x-anime-multi-episode-example naming-example\"></p>\n        </div>\n    </div>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Series Folder Example</label>\n\n        <div class=\"col-sm-8\">\n            <p class=\"form-control-static x-series-folder-example naming-example\"></p>\n        </div>\n    </div>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Season Folder Example</label>\n\n        <div class=\"col-sm-8\">\n            <p class=\"form-control-static x-season-folder-example naming-example\"></p>\n        </div>\n    </div>\n</fieldset>\n";
  return buffer;
  };
this["T"]["settings/mediamanagement/permissions/permissionsview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<fieldset class=\"advanced-setting\">\n    <legend>Permissions</legend>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Set Permissions</label>\n\n        <div class=\"col-sm-8\">\n            <div class=\"input-group\">\n                <label class=\"checkbox toggle well\">\n                    <input type=\"checkbox\" name=\"setPermissionsLinux\"/>\n                    <p>\n                        <span>Yes</span>\n                        <span>No</span>\n                    </p>\n\n                    <div class=\"btn btn-primary slide-button\"/>\n                </label>\n\n                <span class=\"help-inline-checkbox\">\n                    <i class=\"icon-nd-form-info\" title=\"Should chmod/chown be run when files are imported/renamed?\"/>\n                    <i class=\"icon-nd-form-warning\" title=\"If you're unsure what these settings do, do not alter them.\"/>\n                </span>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">File chmod mask</label>\n\n        <div class=\"col-sm-1 col-sm-push-4 help-inline\">\n            <i class=\"icon-nd-form-info\" title=\"Octal, applied to media files when imported/renamed by Sonarr\"/>\n        </div>\n\n        <div class=\"col-sm-4 col-sm-pull-1\">\n            <input type=\"text\" name=\"fileChmod\" class=\"form-control\"/>\n        </div>\n    </div>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Folder chmod mask</label>\n\n        <div class=\"col-sm-1 col-sm-push-4 help-inline\">\n            <i class=\"icon-nd-form-info\" title=\"Octal, applied to series/season folders created by Sonarr\"/>\n        </div>\n\n        <div class=\"col-sm-4 col-sm-pull-1\">\n            <input type=\"text\" name=\"folderChmod\" class=\"form-control\"/>\n        </div>\n    </div>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">chown User</label>\n\n        <div class=\"col-sm-1 col-sm-push-4 help-inline\">\n            <i class=\"icon-nd-form-info\" title=\"Username or uid. Use uid for remote file systems.\"/>\n        </div>\n\n        <div class=\"col-sm-4 col-sm-pull-1\">\n            <input type=\"text\" name=\"chownUser\" class=\"form-control\"/>\n        </div>\n    </div>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">chown Group</label>\n\n        <div class=\"col-sm-1 col-sm-push-4 help-inline\">\n            <i class=\"icon-nd-form-info\" title=\"Group name or gid. Use gid for remote file systems.\"/>\n        </div>\n\n        <div class=\"col-sm-4 col-sm-pull-1\">\n            <input type=\"text\" name=\"chownGroup\" class=\"form-control\"/>\n        </div>\n    </div>\n</fieldset>\n";
  };
this["T"]["settings/mediamanagement/sorting/sortingview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, self=this, functionType="function", blockHelperMissing=helpers.blockHelperMissing;

function program1(depth0,data) {
  
  
  return "\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Skip Free Space Check</label>\n\n        <div class=\"col-sm-9\">\n            <div class=\"input-group\">\n                <label class=\"checkbox toggle well\">\n                    <input type=\"checkbox\" name=\"skipFreeSpaceCheckWhenImporting\"/>\n\n                    <p>\n                        <span>Yes</span>\n                        <span>No</span>\n                    </p>\n\n                    <div class=\"btn btn-primary slide-button\"/>\n                </label>\n\n                <span class=\"help-inline-checkbox\">\n                    <i class=\"icon-nd-form-info\" title=\"Use when drone is unable to detect free space from your series root folder\"/>\n                </span>\n            </div>\n        </div>\n    </div>\n";
  }

  buffer += "<fieldset class=\"advanced-setting\">\n    <legend>Folders</legend>\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Create empty series folders</label>\n\n        <div class=\"col-sm-9\">\n            <div class=\"input-group\">\n                <label class=\"checkbox toggle well\">\n                    <input type=\"checkbox\" name=\"createEmptySeriesFolders\"/>\n\n                    <p>\n                        <span>Yes</span>\n                        <span>No</span>\n                    </p>\n\n                    <div class=\"btn btn-primary slide-button\"/>\n                </label>\n\n                <span class=\"help-inline-checkbox\">\n                    <i class=\"icon-nd-form-info\" title=\"Create missing series folders during disk scan\"/>\n                </span>\n            </div>\n        </div>\n    </div>\n</fieldset>\n\n<fieldset class=\"advanced-setting\">\n    <legend>Importing</legend>\n\n";
  options={hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data}
  if (helper = helpers.if_mono) { stack1 = helper.call(depth0, options); }
  else { helper = (depth0 && depth0.if_mono); stack1 = typeof helper === functionType ? helper.call(depth0, options) : helper; }
  if (!helpers.if_mono) { stack1 = blockHelperMissing.call(depth0, stack1, {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data}); }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n    <div class=\"form-group\">\n        <label class=\"col-sm-3 control-label\">Use Hardlinks instead of Copy</label>\n\n        <div class=\"col-sm-9\">\n            <div class=\"input-group\">\n                <label class=\"checkbox toggle well\">\n                    <input type=\"checkbox\" name=\"copyUsingHardlinks\"/>\n\n                    <p>\n                        <span>Yes</span>\n                        <span>No</span>\n                    </p>\n\n                    <div class=\"btn btn-primary slide-button\"/>\n                </label>\n\n                <span class=\"help-inline-checkbox\">\n                    <i class=\"icon-nd-form-info\" title=\"Use Hardlinks when trying to copy files from torrents that are still being seeded\"/>\n                    <i class=\"icon-nd-form-warning\" title=\"Occasionally, file locks may prevent renaming files that are being seeded. You may temporarily disable seeding and use Sonarr's rename function as a work around.\"/>\n                </span>\n            </div>\n        </div>\n    </div>\n</fieldset>\n";
  return buffer;
  };
this["T"]["settings/notifications/add/notificationaddcollectionview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        <h3>Add Notification</h3>\n    </div>\n    <div class=\"modal-body\">\n        <div class=\"add-notifications add-thingies\">\n            <ul class=\"items\"></ul>\n        </div>\n    </div>\n    <div class=\"modal-footer\">\n        <button class=\"btn\" data-dismiss=\"modal\">close</button>\n    </div>\n</div>\n";
  };
this["T"]["settings/notifications/add/notificationadditemview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n        <div class=\"btn-group\">\n            <button class=\"btn btn-xs btn-default dropdown-toggle\" data-toggle=\"dropdown\">\n                Presets\n                <span class=\"caret\"></span>\n            </button>\n            <ul class=\"dropdown-menu\">\n                ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.presets), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            </ul>\n        </div>\n        ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                <li class=\"x-preset\" data-id=\"";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n                    <a>";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</a>\n                </li>\n                ";
  return buffer;
  }

function program4(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n        <a class=\"btn btn-xs btn-default x-info\" href=\"";
  if (helper = helpers.infoLink) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.infoLink); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n            <i class=\"icon-info-sign\"/>\n        </a>\n        ";
  return buffer;
  }

  buffer += "<div class=\"add-thingy\">\n    <div>\n        ";
  if (helper = helpers.implementation) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.implementation); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n    </div>\n    <div class=\"pull-right\">\n        ";
  stack1 = (helper = helpers.if_gt || (depth0 && depth0.if_gt),options={hash:{
    'compare': (0)
  },inverse:self.noop,fn:self.program(1, program1, data),data:data},helper ? helper.call(depth0, ((stack1 = (depth0 && depth0.presets)),stack1 == null || stack1 === false ? stack1 : stack1.length), options) : helperMissing.call(depth0, "if_gt", ((stack1 = (depth0 && depth0.presets)),stack1 == null || stack1 === false ? stack1 : stack1.length), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.infoLink), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n</div>";
  return buffer;
  };
this["T"]["settings/notifications/delete/notificationdeleteview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        <h3>Delete Notification</h3>\n    </div>\n    <div class=\"modal-body\">\n        <p>Are you sure you want to delete '";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "'?</p>\n    </div>\n    <div class=\"modal-footer\">\n        <button class=\"btn\" data-dismiss=\"modal\">cancel</button>\n        <button class=\"btn btn-danger x-confirm-delete\">delete</button>\n    </div>\n</div>";
  return buffer;
  };
this["T"]["settings/notifications/edit/notificationeditview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n            <h3>Edit - ";
  if (helper = helpers.implementation) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.implementation); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h3>\n        ";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n            <h3>Add - ";
  if (helper = helpers.implementation) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.implementation); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h3>\n        ";
  return buffer;
  }

function program5(depth0,data) {
  
  
  return "\n            <button class=\"btn btn-danger pull-left x-delete\">delete</button>\n        ";
  }

function program7(depth0,data) {
  
  
  return "\n            <button class=\"btn pull-left x-back\">back</button>\n        ";
  }

  buffer += "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.id), {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n    <div class=\"modal-body notification-modal\">\n        <div class=\"form-horizontal\">\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Name</label>\n\n                <div class=\"col-sm-5\">\n                    <input type=\"text\" name=\"name\" class=\"form-control\"/>\n                </div>\n            </div>\n\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">On Grab</label>\n\n                <div class=\"col-sm-5\">\n                    <div class=\"input-group\">\n                        <label class=\"checkbox toggle well\">\n                            <input type=\"checkbox\" name=\"onGrab\"/>\n                            <p>\n                                <span>Yes</span>\n                                <span>No</span>\n                            </p>\n\n                            <div class=\"btn btn-primary slide-button\"/>\n                        </label>\n\n                        <span class=\"help-inline-checkbox\">\n                            <i class=\"icon-nd-form-info\" title=\"Do you want to get notifications when episodes are grabbed?\"/>\n                        </span>\n                    </div>\n                </div>\n            </div>\n\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">On Download</label>\n\n                <div class=\"col-sm-5\">\n                    <div class=\"input-group\">\n                        <label class=\"checkbox toggle well\">\n                            <input type=\"checkbox\" name=\"onDownload\" class=\"x-on-download\"/>\n                            <p>\n                                <span>Yes</span>\n                                <span>No</span>\n                            </p>\n\n                            <div class=\"btn btn-primary slide-button\"/>\n                        </label>\n\n                        <span class=\"help-inline-checkbox\">\n                            <i class=\"icon-nd-form-info\" title=\"Do you want to get notifications when episodes are downloaded?\"/>\n                        </span>\n                    </div>\n                </div>\n            </div>\n\n            <div class=\"form-group x-on-upgrade\">\n                <label class=\"col-sm-3 control-label\">On Upgrade</label>\n\n                <div class=\"col-sm-5\">\n                    <div class=\"input-group\">\n                        <label class=\"checkbox toggle well\">\n                            <input type=\"checkbox\" name=\"onUpgrade\"/>\n                            <p>\n                                <span>Yes</span>\n                                <span>No</span>\n                            </p>\n\n                            <div class=\"btn btn-primary slide-button\"/>\n                        </label>\n\n                        <span class=\"help-inline-checkbox\">\n                            <i class=\"icon-nd-form-info\" title=\"Do you want to get notifications when episodes are upgraded to a better quality?\"/>\n                        </span>\n                    </div>\n                </div>\n            </div>\n\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Tags</label>\n\n                <div class=\"col-sm-5\">\n                    <input type=\"text\" class=\"form-control x-tags\">\n                </div>\n            </div>\n\n            ";
  if (helper = helpers.formBuilder) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.formBuilder); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n        </div>\n    </div>\n    <div class=\"modal-footer\">\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.id), {hash:{},inverse:self.program(7, program7, data),fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n        <span class=\"indicator x-indicator\"><i class=\"icon-spinner icon-spin\"></i></span>\n        <button class=\"btn x-test\">test <i class=\"x-test-icon icon-nd-test\"/></button>\n        <button class=\"btn\" data-dismiss=\"modal\">cancel</button>\n\n        <div class=\"btn-group\">\n            <button class=\"btn btn-primary x-save\">save</button>\n            <button class=\"btn btn-icon-only btn-primary dropdown-toggle\" data-toggle=\"dropdown\">\n                <span class=\"caret\"></span>\n            </button>\n            <ul class=\"dropdown-menu\">\n                <li class=\"save-and-add x-save-and-add\">\n                    save and add\n                </li>\n            </ul>\n        </div>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["settings/profile/delay/delayprofileitemview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, self=this, helperMissing=helpers.helperMissing, functionType="function", escapeExpression=this.escapeExpression;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.enableTorrent), {hash:{},inverse:self.program(7, program7, data),fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("usenet")
  },inverse:self.program(5, program5, data),fn:self.program(3, program3, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.preferredProtocol), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.preferredProtocol), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            ";
  return buffer;
  }
function program3(depth0,data) {
  
  
  return "\n                    Prefer Usenet\n                ";
  }

function program5(depth0,data) {
  
  
  return "\n                    Prefer Torrent\n                ";
  }

function program7(depth0,data) {
  
  
  return "\n                Only Usenet\n            ";
  }

function program9(depth0,data) {
  
  
  return "\n            Only Torrent\n        ";
  }

function program11(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n            ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("0")
  },inverse:self.program(14, program14, data),fn:self.program(12, program12, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.usenetDelay), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.usenetDelay), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        ";
  return buffer;
  }
function program12(depth0,data) {
  
  
  return "\n                No delay\n            ";
  }

function program14(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("1")
  },inverse:self.program(17, program17, data),fn:self.program(15, program15, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.usenetDelay), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.usenetDelay), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            ";
  return buffer;
  }
function program15(depth0,data) {
  
  
  return "\n                    1 minute\n                ";
  }

function program17(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                    ";
  if (helper = helpers.usenetDelay) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.usenetDelay); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " minutes\n                ";
  return buffer;
  }

function program19(depth0,data) {
  
  
  return "\n            -\n        ";
  }

function program21(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n            ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("0")
  },inverse:self.program(22, program22, data),fn:self.program(12, program12, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.torrentDelay), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.torrentDelay), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        ";
  return buffer;
  }
function program22(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("1")
  },inverse:self.program(23, program23, data),fn:self.program(15, program15, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.torrentDelay), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.torrentDelay), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            ";
  return buffer;
  }
function program23(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                    ";
  if (helper = helpers.torrentDelay) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.torrentDelay); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " minutes\n                ";
  return buffer;
  }

function program25(depth0,data) {
  
  
  return "\n                <i class=\"drag-handle icon-reorder x-drag-handle\" title=\"Reorder\"/>\n            ";
  }

  buffer += "    <div class=\"col-sm-2\">\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.enableUsenet), {hash:{},inverse:self.program(9, program9, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n    <div class=\"col-sm-2\">\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.enableUsenet), {hash:{},inverse:self.program(19, program19, data),fn:self.program(11, program11, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n    <div class=\"col-sm-2\">\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.enableTorrent), {hash:{},inverse:self.program(19, program19, data),fn:self.program(21, program21, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n    <div class=\"col-sm-5\">\n        "
    + escapeExpression((helper = helpers.tagDisplay || (depth0 && depth0.tagDisplay),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.tags), options) : helperMissing.call(depth0, "tagDisplay", (depth0 && depth0.tags), options)))
    + "\n    </div>\n    <div class=\"col-sm-1\">\n        <div class=\"pull-right\">\n            ";
  stack1 = (helper = helpers.unless_eq || (depth0 && depth0.unless_eq),options={hash:{
    'compare': ("1")
  },inverse:self.noop,fn:self.program(25, program25, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.id), options) : helperMissing.call(depth0, "unless_eq", (depth0 && depth0.id), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n            <i class=\"icon-nd-edit x-edit\" title=\"Edit\"></i>\n        </div>\n    </div>";
  return buffer;
  };
this["T"]["settings/profile/delay/delayprofilelayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<fieldset class=\"advanced-setting\">\n    <legend>Delay Profiles</legend>\n\n    <div class=\"col-md-12\">\n        <div class=\"rule-setting-list\">\n            <div class=\"rule-setting-header x-header hidden-xs\">\n                <div class=\"row\">\n                    <span class=\"col-sm-2\">Protocol</span>\n                    <span class=\"col-sm-2\">Usenet Delay</span>\n                    <span class=\"col-sm-2\">Torrent Delay</span>\n                    <span class=\"col-sm-5\">Tags</span>\n                </div>\n            </div>\n            <div class=\"rows x-rows\"></div>\n            <div class=\"rule-setting-footer\">\n                <div class=\"pull-right\">\n                    <span class=\"add-rule-setting-mapping\">\n                        <i class=\"icon-nd-add x-add\" title=\"Add new delay profile\" />\n                    </span>\n                </div>\n            </div>\n        </div>\n    </div>\n</fieldset>";
  };
this["T"]["settings/profile/edit/editprofileitemview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<i class=\"select-handle pull-left x-select\" />\n<span class=\"quality-label\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.quality)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</span>\n<i class=\"drag-handle pull-right icon-reorder advanced-setting x-drag-handle\" />\n";
  return buffer;
  };
this["T"]["settings/profile/edit/editprofilelayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, self=this;

function program1(depth0,data) {
  
  
  return "\n    <h3>Edit</h3>\n    ";
  }

function program3(depth0,data) {
  
  
  return "\n    <h3>Add</h3>\n    ";
  }

function program5(depth0,data) {
  
  
  return "\n        <button class=\"btn btn-danger pull-left x-delete\">delete</button>\n        ";
  }

  buffer += "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n    <button type=\"button\" class=\"close\" aria-hidden=\"true\" data-dismiss=\"modal\">&times;</button>\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.id), {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</div>\n    <div class=\"modal-body\">\n        <div class=\"form-horizontal\">\n            <div id=\"x-fields\"></div>\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Qualities</label>\n\n                <div class=\"col-sm-5\">\n                    <div class=\"controls qualities-controls\">\n                        <span id=\"x-qualities\"></span>\n                    </div>\n                </div>\n\n                <div class=\"col-sm-1 help-inline\">\n                    <i class=\"icon-nd-form-info\" title=\"Qualities higher in the list are more preferred. Only checked qualities will be wanted.\"/>\n                </div>\n            </div>\n        </div>\n    </div>\n    <div class=\"modal-footer\">\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.id), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        <span class=\"indicator x-indicator\"><i class=\"icon-spinner icon-spin\"></i></span>\n        <button class=\"btn\" data-dismiss=\"modal\">cancel</button>\n        <button class=\"btn btn-primary x-save\">save</button>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["settings/profile/edit/editprofileview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                ";
  stack1 = (helper = helpers.unless_eq || (depth0 && depth0.unless_eq),options={hash:{
    'compare': ("unknown")
  },inverse:self.noop,fn:self.program(2, program2, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.nameLower), options) : helperMissing.call(depth0, "unless_eq", (depth0 && depth0.nameLower), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                    <option value=\"";
  if (helper = helpers.nameLower) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.nameLower); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</option>\n                ";
  return buffer;
  }

function program4(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.allowed), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            ";
  return buffer;
  }
function program5(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n            <option value=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.quality)),stack1 == null || stack1 === false ? stack1 : stack1.id)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.quality)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</option>\n            ";
  return buffer;
  }

  buffer += "<div class=\"form-group\">\n    <label class=\"col-sm-3 control-label\">Name</label>\n\n    <div class=\"col-sm-5\">\n        <input type=\"text\" name=\"name\" class=\"form-control\">\n    </div>\n</div>\n\n<div class=\"form-group\">\n    <label class=\"col-sm-3 control-label\">Language</label>\n\n    <div class=\"col-sm-5\">\n        <select class=\"form-control\" name=\"language\">\n            ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.languages), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </select>\n    </div>\n\n    <div class=\"col-sm-1 help-inline\">\n        <i class=\"icon-nd-form-info\" title=\"Series assigned this profile will be look for episodes with the selected language\"/>\n    </div>\n</div>\n\n<div class=\"form-group\">\n    <label class=\"col-sm-3 control-label\">Cutoff</label>\n\n    <div class=\"col-sm-5\">\n        <select class=\"form-control x-cutoff\" name=\"cutoff.id\" validation-name=\"cutoff\">\n            ";
  stack1 = (helper = helpers.eachReverse || (depth0 && depth0.eachReverse),options={hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.items), options) : helperMissing.call(depth0, "eachReverse", (depth0 && depth0.items), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </select>\n    </div>\n\n    <div class=\"col-sm-1 help-inline\">\n        <i class=\"icon-nd-form-info\" title=\"Once this quality is reached Sonarr will no longer download episodes\"/>\n    </div>\n</div>";
  return buffer;
  };
this["T"]["settings/quality/definition/qualitydefinitioncollection"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<fieldset>\n    <legend>Quality Definitions</legend>\n    <div class=\"col-md-11\">\n        <div id=\"quality-definition-list\">\n            <div class=\"quality-header x-header hidden-xs\">\n                <div class=\"row\">\n                    <span class=\"col-md-2 col-sm-3\">Quality</span>\n                    <span class=\"col-md-2 col-sm-3\">Title</span>\n                    <span class=\"col-md-4 col-sm-6\">Size Limit</span>\n                </div>\n            </div>\n            <div class=\"rows x-rows\">\n            </div>\n        </div>\n    </div>\n</fieldset>\n";
  };
this["T"]["settings/quality/definition/qualitydefinitionitemview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "    <span class=\"col-md-2 col-sm-3\">\n        "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.quality)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\n    </span>\n    <span class=\"col-md-2 col-sm-3\">\n        <input type=\"text\" class=\"form-control\" name=\"title\">\n    </span>\n    <span class=\"col-md-4 col-sm-6\">\n        <div class=\"x-slider\"></div>\n        <div class=\"size-label-wrapper\">\n            <div class=\"pull-left\">\n                <span class=\"label label-warning x-min-thirty\"\n                      name=\"thirtyMinuteMinSize\"\n                      title=\"Minimum size for a 30 minute episode\">\n                </span>\n                <span class=\"label label-info x-min-sixty\"\n                      name=\"sixtyMinuteMinSize\"\n                      title=\"Minimum size for a 60 minute episode\">\n                </span>\n            </div>\n            <div class=\"pull-right\">\n                <span class=\"label label-warning x-max-thirty\"\n                      name=\"thirtyMinuteMaxSize\"\n                      title=\"Maximum size for a 30 minute episode\">\n                </span>\n                <span class=\"label label-info x-max-sixty\"\n                      name=\"sixtyMinuteMaxSize\"\n                      title=\"Maximum size for a 60 minute episode\">\n                </span>            \n            </div>\n        </div>\n    </span>";
  return buffer;
  };
this["T"]["shared/toolbar/sorting/sortingbuttoncollectionview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"btn-group sorting-buttons\">\n    <a class=\"btn btn-default dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">\n        Sort <span class=\"caret\"></span>\n    </a>\n    <ul class=\"dropdown-menu\">\n\n    </ul>\n</div>\n";
  };
this["T"]["shared/toolbar/sorting/sortingbuttonview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<a href=\"#\">\n    <span class=\"sorting-title\">";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n    <i class=\"\"></i>\n</a>";
  return buffer;
  };
this["T"]["system/info/about/aboutview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n        <dt>Mono Version</dt>\n        <dd>";
  if (helper = helpers.runtimeVersion) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.runtimeVersion); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n        ";
  return buffer;
  }

  buffer += "<fieldset>\n    <legend>About</legend>\n\n    <dl class=\"dl-horizontal info\">\n        <dt>Version</dt>\n        <dd>";
  if (helper = helpers.version) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.version); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.isMonoRuntime), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n        <dt>AppData directory</dt>\n        <dd>";
  if (helper = helpers.appData) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.appData); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n\n        <dt>Startup directory</dt>\n        <dd>";
  if (helper = helpers.startupPath) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.startupPath); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n    </dl>\n</fieldset>\n\n";
  return buffer;
  };
this["T"]["system/info/diskspace/diskspacelayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<fieldset>\n    <legend>Disk Space</legend>\n\n    <div id=\"x-grid\"/>\n</fieldset>";
  };
this["T"]["system/info/health/healthlayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<fieldset class=\"x-health\">\n    <legend>Health</legend>\n\n    <div id=\"x-health-grid\"/>\n</fieldset>\n\n";
  };
this["T"]["system/info/health/healthokview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"row health-ok\">\n    <div class=\"col-md-12\">No issues with your configuration</div>\n</div>";
  };
this["T"]["system/info/moreinfo/moreinfoview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<fieldset>\n    <legend>More Info</legend>\n\n    <dl class=\"dl-horizontal info\">\n        <dt>Home page</dt>\n        <dd><a href=\"https://sonarr.tv/\">sonarr.tv</a></dd>\n\n        <dt>Wiki</dt>\n        <dd><a href=\"https://wiki.sonarr.tv/\">wiki.sonarr.tv</a></dd>\n\n        <dt>Forums</dt>\n        <dd><a href=\"https://forums.sonarr.tv/\">forums.sonarr.tv</a></dd>\n\n        <dt>Twitter</dt>\n        <dd><a href=\"https://twitter.com/sonarrtv\">@sonarrtv</a></dd>\n\n        <dt>IRC</dt>\n        <dd><a href=\"irc://irc.freenode.net/#sonarr\">#sonarr on Freenode</a> or (<a href=\"http://webchat.freenode.net/?channels=#sonarr\">webchat</a>)</dd>\n\n        <dt>Source</dt>\n        <dd><a href=\"https://github.com/Sonarr/Sonarr/\">github.com/Sonarr/Sonarr</a></dd>\n\n        <dt>Feature Requests</dt>\n        <dd><a href=\"https://trello.com/b/MadvFKy4/sonarr\">trello.com/b/MadvFKy4/sonarr</a></dd>\n    </dl>\n</fieldset>\n\n";
  };
this["T"]["system/logs/files/contentsview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"row\">\n    <div class=\"col-md-12\">\n        <h3>";
  if (helper = helpers.filename) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.filename); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h3>\n    </div>\n</div>\n\n<div class=\"row\">\n    <div class=\"col-md-12\">\n        <pre>";
  if (helper = helpers.contents) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.contents); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</pre>\n    </div>\n</div>";
  return buffer;
  };
this["T"]["system/logs/files/logfilelayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div id=\"x-toolbar\"/>\n<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div id=\"x-grid\"/>\n    </div>\n</div>\n\n<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div id=\"x-contents\"/>\n    </div>\n</div>";
  };
this["T"]["system/logs/table/logstablelayout"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div id=\"x-toolbar\"/>\n<div class=\"row\">\n    <div class=\"col-md-12 table-responsive\">\n        <div id=\"x-grid\"/>\n    </div>\n</div>\n<div class=\"row\">\n    <div class=\"col-md-12\">\n        <div id=\"x-pager\"/>\n    </div>\n</div>\n";
  };
this["T"]["settings/mediamanagement/naming/basic/basicnamingview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"form-group\">\n    <label class=\"col-sm-3 control-label\">Include Series Title</label>\n\n    <div class=\"col-sm-9\">\n        <div class=\"input-group\">\n            <label class=\"checkbox toggle well\">\n                <input type=\"checkbox\" name=\"includeSeriesTitle\"/>\n\n                <p>\n                    <span>Yes</span>\n                    <span>No</span>\n                </p>\n\n                <div class=\"btn btn-primary slide-button\"/>\n            </label>\n        </div>\n    </div>\n</div>\n\n\n\n<div class=\"form-group\">\n    <label class=\"col-sm-3 control-label\">Include Episode Title</label>\n\n    <div class=\"col-sm-9\">\n        <div class=\"input-group\">\n            <label class=\"checkbox toggle well\">\n                <input type=\"checkbox\" name=\"includeEpisodeTitle\"/>\n\n                <p>\n                    <span>Yes</span>\n                    <span>No</span>\n                </p>\n\n                <div class=\"btn btn-primary slide-button\"/>\n            </label>\n        </div>\n    </div>\n</div>\n\n<div class=\"form-group\">\n    <label class=\"col-sm-3 control-label\">Include Quality</label>\n\n    <div class=\"col-sm-9\">\n        <div class=\"input-group\">\n            <label class=\"checkbox toggle well\">\n                <input type=\"checkbox\" name=\"includeQuality\"/>\n\n                <p>\n                    <span>Yes</span>\n                    <span>No</span>\n                </p>\n\n                <div class=\"btn btn-primary slide-button\"/>\n            </label>\n        </div>\n    </div>\n</div>\n\n<div class=\"form-group\">\n    <label class=\"col-sm-3 control-label\">Replace Spaces</label>\n\n    <div class=\"col-sm-9\">\n        <div class=\"input-group\">\n            <label class=\"checkbox toggle well\">\n                <input type=\"checkbox\" name=\"replaceSpaces\"/>\n\n                <p>\n                    <span>Yes</span>\n                    <span>No</span>\n                </p>\n\n                <div class=\"btn btn-primary slide-button\"/>\n            </label>\n        </div>\n    </div>\n</div>\n\n<div class=\"form-group\">\n    <label class=\"col-sm-3 control-label\">Separator</label>\n\n    <div class=\"col-sm-9\">\n        <select class=\"form-control\" name=\"separator\">\n            <option value=\" - \">Dash</option>\n            <option value=\" \">Space</option>\n            <option value=\".\">Period</option>\n        </select>\n    </div>\n</div>\n\n<div class=\"form-group\">\n    <label class=\"col-sm-3 control-label\">Numbering Style</label>\n\n    <div class=\"col-sm-9\">\n        <select class=\"form-control\" name=\"numberStyle\">\n            <option value=\"{season}x{episode:00}\">1x05</option>\n            <option value=\"{season:00}x{episode:00}\">01x05</option>\n            <option value=\"S{season:00}E{episode:00}\">S01E05</option>\n            <option value=\"s{season:00}e{episode:00}\">s01e05</option>\n        </select>\n    </div>\n</div>\n";
  };
this["T"]["settings/profile/delay/delete/delayprofiledeleteview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n        <h3>Delete Delay Profile</h3>\n    </div>\n    <div class=\"modal-body\">\n        <p>Are you sure you want to delete this delay profile?</p>\n    </div>\n    <div class=\"modal-footer\">\n        <button class=\"btn\" data-dismiss=\"modal\">cancel</button>\n        <button class=\"btn btn-danger x-confirm-delete\">delete</button>\n    </div>\n</div>\n";
  };
this["T"]["settings/profile/delay/edit/delayprofileeditview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  
  return "\n            <h3>Edit - Delay Profile</h3>\n        ";
  }

function program3(depth0,data) {
  
  
  return "\n            <h3>Add - Delay Profile</h3>\n        ";
  }

function program5(depth0,data) {
  
  
  return "\n                <div class=\"alert alert-info\" role=\"alert\">This is the default profile. It applies to all series that don't have an explicit profile.</div>\n            ";
  }

function program7(depth0,data) {
  
  
  return "\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Tags</label>\n\n                <div class=\"col-sm-1 col-sm-push-5 help-inline\">\n                    <i class=\"icon-nd-form-info\" title=\"One or more tags to apply these rules to matching series\" />\n                </div>\n\n                <div class=\"col-sm-5 col-sm-pull-1\">\n                    <input type=\"text\" class=\"form-control x-tags\">\n                </div>\n            </div>\n            ";
  }

function program9(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n            ";
  stack1 = (helper = helpers.if_gt || (depth0 && depth0.if_gt),options={hash:{
    'compare': ("1")
  },inverse:self.noop,fn:self.program(10, program10, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.id), options) : helperMissing.call(depth0, "if_gt", (depth0 && depth0.id), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        ";
  return buffer;
  }
function program10(depth0,data) {
  
  
  return "\n                <button class=\"btn btn-danger pull-left x-delete\">delete</button>\n            ";
  }

  buffer += "<div class=\"modal-content\">\n    <div class=\"modal-header\">\n        <button type=\"button\" class=\"close\" aria-hidden=\"true\" data-dismiss=\"modal\">&times;</button>\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.id), {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n    <div class=\"modal-body indexer-modal\">\n        <div class=\"form-horizontal\">\n            <div class=\"form-group\">\n                <label class=\"col-sm-3 control-label\">Protocol</label>\n\n                <div class=\"col-sm-1 col-sm-push-5 help-inline\">\n                    <i class=\"icon-nd-form-info\" title=\"Choose which protocol(s) to use and which one is preferred when choosing between otherwise equal releases\" />\n                </div>\n\n                <div class=\"col-sm-5 col-sm-pull-1\">\n                    <select class=\"form-control x-protocol\">\n                        <option value=\"preferUsenet\">Prefer Usenet</option>\n                        <option value=\"preferTorrent\">Prefer Torrent</option>\n                        <option value=\"onlyUsenet\">Only Usenet</option>\n                        <option value=\"onlyTorrent\">Only Torrent</option>\n                    </select>\n                </div>\n            </div>\n\n            <div class=\"form-group x-usenet-delay\">\n                <label class=\"col-sm-3 control-label\">Usenet Delay</label>\n\n                <div class=\"col-sm-1 col-sm-push-5 help-inline\">\n                    <i class=\"icon-nd-form-info\" title=\"Delay in minutes to wait before grabbing a release from Usenet\" />\n                </div>\n\n                <div class=\"col-sm-5 col-sm-pull-1\">\n                    <input type=\"number\" class=\"form-control\" name=\"usenetDelay\"/>\n                </div>\n            </div>\n\n            <div class=\"form-group x-torrent-delay\">\n                <label class=\"col-sm-3 control-label\">Torrent Delay</label>\n\n                <div class=\"col-sm-1 col-sm-push-5 help-inline\">\n                    <i class=\"icon-nd-form-info\" title=\"Delay in minutes to wait before grabbing a torrent\" />\n                </div>\n\n                <div class=\"col-sm-5 col-sm-pull-1\">\n                    <input type=\"number\" class=\"form-control\" name=\"torrentDelay\"/>\n                </div>\n            </div>\n\n            ";
  stack1 = (helper = helpers.if_eq || (depth0 && depth0.if_eq),options={hash:{
    'compare': ("1")
  },inverse:self.program(7, program7, data),fn:self.program(5, program5, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.id), options) : helperMissing.call(depth0, "if_eq", (depth0 && depth0.id), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </div>\n    </div>\n    <div class=\"modal-footer\">\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.id), {hash:{},inverse:self.noop,fn:self.program(9, program9, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        <span class=\"indicator x-indicator\"><i class=\"icon-spinner icon-spin\"></i></span>\n        <button class=\"btn\" data-dismiss=\"modal\">cancel</button>\n        <button class=\"btn btn-primary x-save\">save</button>\n    </div>\n</div>\n";
  return buffer;
  };
this["T"]["system/logs/table/details/logdetailsview"] = function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                <br/>\n                Exception\n                <pre>";
  if (helper = helpers.exception) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.exception); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</pre>\n            ";
  return buffer;
  }

  buffer += "<div class=\"modal-content\">\n    <div class=\"log-details-modal\">\n        <div class=\"modal-header\">\n            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\n\n            <h3>Details</h3>\n\n        </div>\n        <div class=\"modal-body\">\n            Message\n            <pre>";
  if (helper = helpers.message) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.message); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</pre>\n\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.exception), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </div>\n        <div class=\"modal-footer\">\n            <button class=\"btn\" data-dismiss=\"modal\">close</button>\n        </div>\n    </div>\n</div>\n";
  return buffer;
  };
return this["T"];

});
